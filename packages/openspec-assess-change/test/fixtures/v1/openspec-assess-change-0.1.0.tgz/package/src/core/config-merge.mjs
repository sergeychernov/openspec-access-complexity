// Effective configuration = shipped defaults ← explicit user overrides.
// Rules: objects merge by known schema keys; arrays of entries with "id" merge by id
// (new ids are appended); other arrays and scalars replace. Absent keys inherit; explicit
// 0, false and null are values. Unknown keys are errors, never ignored.
import { configSchema } from './schemas.mjs';
import { clone, canonicalStringify } from './canonical.mjs';
import { structuralErrors, configErrors, assertValid } from './validate.mjs';
import { FACTOR_IDS } from './factors.mjs';
import { ValidationError } from './jsonschema.mjs';

function deref(node) {
  let refName = null;
  while (node && node.$ref) {
    refName = node.$ref;
    node = node.$ref.slice(2).split('/').reduce((n, p) => n[p], configSchema);
  }
  return { node, refName };
}

function objectBranch(node) {
  if (node.type === 'object') return node;
  if (node.anyOf) {
    for (const b of node.anyOf) {
      const { node: n } = deref(b);
      if (n.type === 'object') return n;
    }
  }
  return null;
}

const isPlain = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const esc = (k) => String(k).replace(/~/g, '~0').replace(/\//g, '~1');

function mergeNode(schemaNode, base, over, path, ctx) {
  const { node, refName } = deref(schemaNode);
  if (isPlain(over)) {
    const obj = objectBranch(node);
    if (!obj) {
      ctx.errors.push({ path: path || '/', message: 'object given where a scalar or array is expected' });
      return base;
    }
    if (refName === '#/$defs/coefficient') return mergeCoefficient(obj, base, over, path, ctx);
    const result = isPlain(base) ? { ...base } : {};
    for (const key of Object.keys(over)) {
      const p = `${path}/${esc(key)}`;
      if (key === 'id' && isPlain(base) && base.id === over.id) continue;
      let child;
      if (obj.propertyNames && obj.propertyNames.enum && !obj.propertyNames.enum.includes(key)) {
        ctx.errors.push({ path: p, message: `unknown key "${key}"` });
        continue;
      }
      if (obj.properties && key in obj.properties) child = obj.properties[key];
      else if (obj.additionalProperties && typeof obj.additionalProperties === 'object') child = obj.additionalProperties;
      else { ctx.errors.push({ path: p, message: `unknown key "${key}"` }); continue; }
      result[key] = mergeNode(child, isPlain(base) ? base[key] : undefined, over[key], p, ctx);
    }
    return result;
  }
  if (Array.isArray(over) && Array.isArray(base) && node.type === 'array' && node.items) {
    const { node: itemNode } = deref(node.items);
    if (itemNode.type === 'object' && itemNode.properties && itemNode.properties.id) {
      const result = base.map((x) => x);
      for (const [i, item] of over.entries()) {
        if (!isPlain(item) || typeof item.id !== 'string') {
          ctx.errors.push({ path: `${path}/${i}/id`, message: 'override entries in this list are matched by "id"' });
          continue;
        }
        const idx = result.findIndex((x) => x.id === item.id);
        if (idx >= 0) result[idx] = mergeNode(node.items, result[idx], item, `${path}/${idx}`, ctx);
        else {
          result.push(clone(item));
          ctx.paths.push(`${path}/${result.length - 1}`);
        }
      }
      return result;
    }
  }
  ctx.paths.push(path || '/');
  return clone(over);
}

function mergeCoefficient(obj, base, over, path, ctx) {
  for (const key of Object.keys(over)) {
    if (!(key in obj.properties)) ctx.errors.push({ path: `${path}/${esc(key)}`, message: `unknown key "${key}"` });
  }
  const result = isPlain(base) ? { ...base } : {};
  for (const key of Object.keys(over)) if (key in obj.properties) result[key] = clone(over[key]);
  if ('value' in over && !('status' in over)) {
    result.status = over.value === null ? 'unknown' : 'user-override';
    if (!('basis' in over)) result.basis = `user override${base && base.basis ? ` (shipped basis: ${base.basis})` : ''}`;
    if (result.status === 'user-override') delete result.sources;
    delete result.inheritedFrom;
  }
  ctx.paths.push(path);
  ctx.touchedCoefficients.add(path);
  return result;
}

const downgrade = (status) => (status === 'unknown' || status === 'user-override' ? status : 'proxy');

// When an override changes modelId or harness of a catalog entry, carried-over evidence keeps
// its original identity: coefficients not explicitly overridden become proxy + inheritedFrom.
function markInherited(effective, defaults, ctx) {
  effective.models.forEach((m, i) => {
    const orig = defaults.models.find((d) => d.id === m.id);
    if (!orig || (orig.modelId === m.modelId && orig.harness === m.harness)) return;
    const from = (coef) => coef.inheritedFrom || { modelId: orig.modelId, harness: orig.harness, status: coef.status };
    for (const phase of ['apply', 'verify']) {
      const pc = m.coefficients[phase];
      const mark = (coef, p) => {
        if (ctx.touchedCoefficients.has(p) || coef.status === 'user-override') return coef;
        if (coef.status === 'unknown') return coef;
        return { ...coef, status: downgrade(coef.status), inheritedFrom: from(coef) };
      };
      const newBase = {};
      for (const f of FACTOR_IDS) newBase[f] = mark(pc.base[f], `/models/${i}/coefficients/${phase}/base/${f}`);
      pc.base = newBase;
      if (pc.byEffort) {
        for (const [e, map] of Object.entries(pc.byEffort)) {
          for (const [f, coef] of Object.entries(map)) map[f] = mark(coef, `/models/${i}/coefficients/${phase}/byEffort/${e}/${f}`);
        }
      }
      if (pc.effortDelta) {
        for (const [e, d] of Object.entries(pc.effortDelta)) {
          if (d.status === 'measured') pc.effortDelta[e] = { ...d, status: 'proxy', basis: `${d.basis} (inherited from ${orig.harness}/${orig.modelId})` };
        }
      }
    }
    if (!ctx.paths.some((p) => p.startsWith(`/models/${i}/identity`))) {
      m.identity = { ...m.identity, status: 'unconfirmed', note: `modelId/harness changed from ${orig.harness}/${orig.modelId}; identity not re-verified` };
    }
    if (!ctx.paths.some((p) => p.startsWith(`/models/${i}/clientModelId`)) && orig.modelId !== m.modelId) {
      m.clientModelId = null;
    }
  });
}

export function mergeConfig(defaults, overrides = null, { defaultsLabel = 'config/defaults.json' } = {}) {
  assertValid('defaults', configErrors(defaults));
  const effective = clone(defaults);
  delete effective.provenance;
  const ctx = { errors: [], paths: [], touchedCoefficients: new Set() };
  let merged = effective;
  if (overrides !== null) {
    assertValid('overrides', structuralErrors('overrides', overrides));
    const set = overrides.set;
    for (const k of ['kind', 'schemaVersion', 'provenance']) {
      if (k in set) ctx.errors.push({ path: `/${k}`, message: `"${k}" cannot be overridden` });
    }
    const filtered = Object.fromEntries(Object.entries(set).filter(([k]) => !['kind', 'schemaVersion', 'provenance'].includes(k)));
    merged = mergeNode(configSchema, effective, filtered, '', ctx);
    if (ctx.errors.length) throw new ValidationError('overrides', ctx.errors.map((e) => ({ path: `/set${e.path}`, message: e.message })));
    markInherited(merged, defaults, ctx);
  }
  merged.provenance = { defaults: defaultsLabel, overridePaths: [...new Set(ctx.paths)].sort() };
  assertValid('effective config', configErrors(merged));
  return merged;
}

// Builds an overrides document that turns `defaults` into `edited` (used by the configurator export).
export function diffToOverrides(defaults, edited, note) {
  const set = diffNode(configSchema, defaults, edited);
  return { kind: 'openspec-assess.overrides', schemaVersion: 1, ...(note ? { note } : {}), set: set || {} };
}

function diffNode(schemaNode, a, b) {
  if (canonicalStringify(a === undefined ? null : a) === canonicalStringify(b === undefined ? null : b) && a !== undefined) return undefined;
  const { node, refName } = deref(schemaNode);
  if (isPlain(a) && isPlain(b) && refName !== '#/$defs/coefficient') {
    const obj = objectBranch(node);
    if (obj) {
      const out = {};
      for (const key of Object.keys(b)) {
        if (key === 'provenance') continue;
        const child = (obj.properties && obj.properties[key]) || (typeof obj.additionalProperties === 'object' ? obj.additionalProperties : true);
        const d = child === true ? (canonicalStringify(a[key] ?? null) === canonicalStringify(b[key]) && key in a ? undefined : b[key]) : diffNode(child, a[key], b[key]);
        if (d !== undefined) out[key] = d;
      }
      return Object.keys(out).length ? out : undefined;
    }
  }
  if (Array.isArray(a) && Array.isArray(b) && node.type === 'array' && node.items) {
    const { node: itemNode } = deref(node.items);
    if (itemNode.type === 'object' && itemNode.properties && itemNode.properties.id) {
      const out = [];
      for (const item of b) {
        const prev = a.find((x) => x.id === item.id);
        if (!prev) { out.push(item); continue; }
        const d = diffNode(node.items, prev, item);
        if (d !== undefined) out.push({ id: item.id, ...d });
      }
      return out.length ? out : undefined;
    }
  }
  if (refName === '#/$defs/coefficient' && isPlain(a) && isPlain(b)) {
    return canonicalStringify(a) === canonicalStringify(b) ? undefined : clone(b);
  }
  return clone(b);
}
