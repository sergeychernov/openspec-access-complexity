// Markdown renderer (renderer version 1). Pure, locale-independent formatting.
import { RANKING_KEYS } from './ranking.mjs';
import { FACTOR_IDS, RUBRIC } from './factors.mjs';

const dash = '—';
const bp = (v) => (v === null || v === undefined ? dash : String(v));
const pad = (n, w) => String(n).padStart(w, '0');

export function formatMicros(micros, currency) {
  if (micros === null || micros === undefined) return `${currency} unknown`;
  const whole = Math.floor(micros / 1000000);
  const frac = micros % 1000000;
  return `${currency} ${whole}.${pad(Math.floor(frac / 100), 4)}`;
}

function cell(s) {
  return String(s).replace(/\|/g, '\\|').replace(/\n/g, ' ');
}

function idx(i) {
  return i ? `${i.lower}–${i.upper} (ranking ${i.ranking})` : 'not defined';
}

const TITLES = {
  'apply/api': 'Apply · API',
  'verify/api': 'Verify · API',
  'apply/subscription': 'Apply · Subscription',
  'verify/subscription': 'Verify · Subscription',
};

function resourceText(c, mode, currency) {
  if (mode === 'api') {
    const r = c.resource;
    if (r.status !== 'known') return `unknown${r.notes.length ? ` (${r.notes[0]})` : ''}`;
    return `${formatMicros(r.lowMicros, currency)} / ${formatMicros(r.typicalMicros, currency)} / ${formatMicros(r.highMicros, currency)}`;
  }
  const r = c.resource;
  const load = r.status === 'known' ? `${r.lowLoad} / ${r.typicalLoad} / ${r.highLoad}` : 'unknown';
  return `${load}; capacity ${r.capacity.status}`;
}

export function renderMarkdown(report) {
  const L = [];
  const p = report.properties;
  L.push(`# Assessment: ${report.change.name} (${report.change.stage})`);
  L.push('');
  L.push(`Evaluator ${report.version.evaluator}, renderer ${report.version.renderer}, package ${report.version.package}. As-of: ${report.asOf ?? 'not set'}.`);
  if (report.change.previousAssessmentId) L.push(`Previous assessment: \`${report.change.previousAssessmentId}\`.`);
  L.push(`Scope: ${report.change.scope.mode === 'all-tasks' ? 'all tasks' : report.change.scope.taskIds.join(', ')}.`);
  L.push('');
  for (const d of report.disclaimers) L.push(`> ${d}`);
  L.push('');
  L.push('## Change properties (model-independent)');
  L.push('');
  L.push('| Index | Basis points 0–10000 |');
  L.push('| --- | --- |');
  for (const g of ['volume', 'complexity', 'risk', 'uncertainty']) L.push(`| ${g} | ${idx(p.indices[g])} |`);
  L.push('');
  L.push(`Workload category: low ${p.workload.low}, typical ${p.workload.typical}, high ${p.workload.high}. Quality demand: ${p.demandBp} bp.`);
  L.push('');
  L.push('| Factor | State | Kind | Level (lower–upper) | Ranking level |');
  L.push('| --- | --- | --- | --- | --- |');
  for (const f of FACTOR_IDS) {
    const v = p.factors[f];
    const range = v.lower === null ? dash : `${v.lower}–${v.upper}`;
    L.push(`| ${RUBRIC[f].title} (\`${f}\`) | ${v.state} | ${v.kind ?? dash} | ${range} | ${v.rankingLevel ?? dash} |`);
  }
  L.push('');
  const md = report.missingData;
  L.push(`Missing data: unknown factors ${md.unknownFactors.length ? md.unknownFactors.join(', ') : 'none'}; unknown quantities ${md.unknownQuantities.length ? md.unknownQuantities.join(', ') : 'none'}; unknown share ${md.unknownShareBp} bp. ${md.unknownPolicy}.`);
  L.push('');

  for (const key of RANKING_KEYS) {
    const r = report.rankings[key];
    const [, mode] = key.split('/');
    L.push(`## ${TITLES[key]}`);
    L.push('');
    L.push(`Status: **${r.status}**. ${r.message}`);
    L.push(`Quality floor: ${r.qualityFloorBp} bp (demand ${r.demandBp}). Selection weights: quality ${r.selectionWeights.quality}, economy ${r.selectionWeights.economy}, time ${r.selectionWeights.time}.`);
    if (r.recommended) L.push(`Top of list for manual choice: \`${r.recommended.candidateId}\` at effort \`${r.recommended.effort}\`.`);
    L.push('');
    if (r.candidates.length) {
      const resHeader = mode === 'api' ? 'API cost low / typical / high' : 'Relative load low / typical / high';
      L.push(`| # | Candidate | Group | Effort | Suitability (heuristic) | Coverage | Utility | ${resHeader} | Notes |`);
      L.push('| --- | --- | --- | --- | --- | --- | --- | --- | --- |');
      for (const c of r.candidates) {
        const cur = c.resource.currency || '';
        L.push(`| ${c.rank} | ${cell(c.displayName)} \`${cell(c.candidateId)}\` | ${c.group} | ${c.recommendedEffort} | ${bp(c.suitability.valueBp)} | ${c.suitability.coverageBp} | ${bp(c.utilityBp)} | ${cell(resourceText(c, mode, cur))} | ${cell(c.reasons.join('; ') || dash)} |`);
      }
      L.push('');
    }
    if (r.excluded.length) {
      L.push('Excluded:');
      for (const e of r.excluded) L.push(`- \`${e.candidateId}\`: ${e.reasons.join('; ')}`);
      L.push('');
    }
    if (r.pools.length) {
      L.push('Quota pools:');
      for (const pool of r.pools) L.push(`- \`${pool.poolId}\` (${pool.label}): ${pool.candidates.join(', ')} — ${pool.status}; ${pool.note}`);
      L.push('');
    }
    const top = r.candidates[0];
    if (top) {
      L.push(`<details><summary>Factor contributions for ${top.candidateId} @ ${top.recommendedEffort}</summary>`);
      L.push('');
      L.push('| Factor | Level | Relevance | Coefficient | Provenance | Contribution |');
      L.push('| --- | --- | --- | --- | --- | --- |');
      for (const k of top.suitability.contributions) {
        const prov = `${k.coefficientStatus}${k.inheritedFrom ? ` (inherited from ${k.inheritedFrom.harness}/${k.inheritedFrom.modelId})` : ''}${k.sources.length ? ` [${k.sources.join(', ')}]` : ''}`;
        L.push(`| ${k.factor} | ${k.level}${k.levelState === 'unknown' ? ' (unknown)' : ''} | ${k.relevance} | ${bp(k.coefficientBp)} | ${cell(prov)} | ${bp(k.contributionBp)} |`);
      }
      L.push('');
      L.push('</details>');
      L.push('');
    }
  }
  if (report.benchmarks.length) {
    L.push('## Benchmark sources');
    L.push('');
    for (const b of report.benchmarks) L.push(`- \`${b.id}\`: ${b.benchmark}, ${b.metric}, ${b.model} — ${b.publisher} (${b.sourceKind}) ${b.url}`);
    L.push('');
  } else {
    L.push('## Benchmark sources');
    L.push('');
    L.push('No benchmark record is referenced by the effective configuration; all coefficients are proxy, heuristic, unknown or user overrides.');
    L.push('');
  }
  return L.join('\n');
}
