// Loading shipped defaults, benchmark snapshot and explicit user overrides.
import { existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { mergeConfig } from '../core/config-merge.mjs';
import { readJsonFile, canonicalDigest } from './fsio.mjs';

export const PACKAGE_ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
export const DEFAULTS_PATH = join(PACKAGE_ROOT, 'config', 'defaults.json');
export const BENCHMARKS_PATH = join(PACKAGE_ROOT, 'config', 'benchmarks.json');

// Overrides precedence: explicit --overrides file, else <changeRoot>/assessment/overrides.json when present.
export function overridesPathFor({ overridesPath = null, changeRoot = null } = {}) {
  if (overridesPath) return overridesPath;
  if (changeRoot) {
    const p = join(changeRoot, 'assessment', 'overrides.json');
    if (existsSync(p)) return p;
  }
  return null;
}

export function loadEffectiveConfig({ overridesPath = null, defaultsPath = DEFAULTS_PATH, benchmarksPath = BENCHMARKS_PATH } = {}) {
  const defaults = readJsonFile(defaultsPath, 'config/defaults.json');
  const overrides = overridesPath ? readJsonFile(overridesPath, 'overrides') : null;
  const benchmarks = readJsonFile(benchmarksPath, 'config/benchmarks.json');
  const effective = mergeConfig(defaults, overrides);
  return {
    defaults,
    overrides,
    benchmarks,
    effective,
    digests: {
      defaults: canonicalDigest(defaults),
      overrides: overrides ? canonicalDigest(overrides) : null,
      effective: canonicalDigest(effective),
    },
  };
}
