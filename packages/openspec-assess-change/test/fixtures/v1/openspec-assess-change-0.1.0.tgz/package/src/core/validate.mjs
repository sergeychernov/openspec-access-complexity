// Structural + semantic validation (pure). Filesystem-dependent checks (existence, digests,
// artifact completeness, task IDs) live in src/node/evidence.mjs.
import { validateSchema, ValidationError } from './jsonschema.mjs';
import {
  profileSchema, configSchema, benchmarksSchema, overridesSchema, manifestSchema, latestSchema, reportSchema, KINDS, SCHEMA_VERSIONS,
} from './schemas.mjs';
import { FACTOR_IDS, JUDGMENT_FACTORS, QUANTITY_IDS } from './factors.mjs';
import { compareCodeUnits } from './canonical.mjs';

function versionGate(doc, type, label) {
  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    return [{ path: '/', message: `${label} must be a JSON object` }];
  }
  if (doc.kind !== KINDS[type]) {
    return [{ path: '/kind', message: `expected "${KINDS[type]}", got ${JSON.stringify(doc.kind)}` }];
  }
  if (doc.schemaVersion !== SCHEMA_VERSIONS[type]) {
    return [{
      path: '/schemaVersion',
      message: `unsupported ${type} schemaVersion ${JSON.stringify(doc.schemaVersion)}; this evaluator supports ${SCHEMA_VERSIONS[type]}. Install a package release that supports it; the document is not interpreted as the current version.`,
    }];
  }
  return null;
}

const SCHEMAS = {
  profile: profileSchema,
  config: configSchema,
  benchmarks: benchmarksSchema,
  overrides: overridesSchema,
  manifest: manifestSchema,
  latest: latestSchema,
  report: reportSchema,
};

export function structuralErrors(type, doc, label = type) {
  const gate = versionGate(doc, type, label);
  if (gate) return gate;
  return validateSchema(SCHEMAS[type], doc);
}

// ------------------------------------------------------------------ profile
export function profileErrors(profile) {
  const errors = structuralErrors('profile', profile);
  if (errors.length) return errors;
  const err = (path, message) => errors.push({ path, message });

  const byId = new Map();
  profile.evidence.forEach((e, i) => {
    const p = `/evidence/${i}`;
    if (byId.has(e.id)) err(`${p}/id`, `duplicate evidence id "${e.id}"`);
    byId.set(e.id, { ...e, index: i });
    if (e.path !== undefined && e.base === undefined) err(`${p}/base`, 'is required when path is set');
    if (['artifact', 'requirement', 'task'].includes(e.kind)) {
      if (e.path === undefined) err(`${p}/path`, `is required for ${e.kind} evidence`);
      if (e.base !== undefined && e.base !== 'change') err(`${p}/base`, `${e.kind} evidence is relative to the change root ("change")`);
    }
    if (['requirement', 'task'].includes(e.kind) && e.locator === undefined) {
      err(`${p}/locator`, `is required for ${e.kind} evidence (requirement name or task id)`);
    }
    if (['file', 'check-result'].includes(e.kind)) {
      if (e.path === undefined) err(`${p}/path`, `is required for ${e.kind} evidence`);
      if (e.base !== undefined && e.base !== 'repo') err(`${p}/base`, `${e.kind} evidence is relative to the repository root ("repo")`);
    }
    if (e.kind === 'diff') {
      if (e.revision === undefined) err(`${p}/revision`, 'diff evidence requires the base revision (git diff <revision>)');
      if (e.path !== undefined) err(`${p}/path`, 'diff evidence is identified by revision, not path');
      if (e.digest === undefined) err(`${p}/digest`, 'diff evidence requires the digest of the diff (use pin-evidence)');
    }
    if (e.planned === true) {
      if (e.kind !== 'file') err(`${p}/planned`, 'only file evidence can be planned');
      if (e.digest !== undefined) err(`${p}/digest`, 'a planned (not yet existing) file cannot have a digest');
      if (!e.derivedFrom) err(`${p}/derivedFrom`, 'planned file must reference the task or requirement it follows from');
    } else {
      if (e.derivedFrom !== undefined) err(`${p}/derivedFrom`, 'only planned evidence uses derivedFrom');
      if (e.path !== undefined && e.digest === undefined) {
        err(`${p}/digest`, 'existing local evidence requires a digest (use pin-evidence to fill it)');
      }
    }
  });
  profile.evidence.forEach((e, i) => {
    for (const [j, ref] of (e.derivedFrom || []).entries()) {
      const target = byId.get(ref);
      if (!target) err(`/evidence/${i}/derivedFrom/${j}`, `unknown evidence id "${ref}"`);
      else if (target.planned === true || !['task', 'requirement', 'artifact'].includes(target.kind)) {
        err(`/evidence/${i}/derivedFrom/${j}`, `must reference existing task, requirement or artifact evidence, got ${target.kind}${target.planned ? ' (planned)' : ''}`);
      }
    }
  });

  const checkRefs = (path, refs) => {
    const list = [];
    for (const [j, ref] of (refs || []).entries()) {
      const target = byId.get(ref);
      if (!target) err(`${path}/${j}`, `unknown evidence id "${ref}"`);
      else list.push(target);
    }
    return list;
  };

  for (const q of QUANTITY_IDS) {
    const v = profile.quantities[q];
    const p = `/quantities/${q}`;
    if (v.state === 'known') {
      for (const f of ['kind', 'min', 'max', 'rationale', 'evidence']) if (v[f] === undefined) err(`${p}/${f}`, 'is required for a known quantity');
      if (v.min !== undefined && v.max !== undefined && v.min > v.max) err(`${p}/max`, 'must be >= min');
      const refs = checkRefs(`${p}/evidence`, v.evidence);
      if (v.kind === 'measured') {
        if (v.min !== v.max) err(`${p}/max`, 'a measured quantity is exact (min == max); use estimated for ranges');
        if (refs.length && refs.every((r) => r.planned)) err(`${p}/evidence`, 'measured value needs measurement evidence, not planned files');
        if (['files', 'diffLines', 'generatedFiles'].includes(q) && !refs.some((r) => ['diff', 'check-result'].includes(r.kind))) {
          err(`${p}/evidence`, `measured ${q} requires diff or check-result evidence`);
        }
      }
    } else {
      for (const f of ['kind', 'min', 'max']) if (v[f] !== undefined) err(`${p}/${f}`, `must be absent when state is ${v.state}`);
      if (v.state === 'not-applicable' && v.rationale === undefined) err(`${p}/rationale`, 'not-applicable requires a rationale');
      checkRefs(`${p}/evidence`, v.evidence);
    }
  }

  for (const f of JUDGMENT_FACTORS) {
    const v = profile.factors[f];
    const p = `/factors/${f}`;
    if (v.state === 'known') {
      for (const k of ['level', 'kind', 'rationale', 'evidence']) if (v[k] === undefined) err(`${p}/${k}`, 'is required for a known factor');
      const refs = checkRefs(`${p}/evidence`, v.evidence);
      if (v.kind === 'measured' && refs.some((r) => r.planned)) err(`${p}/kind`, 'a level based on planned files is a forecast, not measured');
    } else {
      for (const k of ['level', 'kind']) if (v[k] !== undefined) err(`${p}/${k}`, `must be absent when state is ${v.state}`);
      if (v.state === 'not-applicable' && v.rationale === undefined) err(`${p}/rationale`, 'not-applicable requires a rationale');
      checkRefs(`${p}/evidence`, v.evidence);
    }
    if (v.details) {
      const allowed = { domains: ['domainIds', 'links', 'tags'], layers: ['layerCategories', 'boundaryCrossings', 'tags'] }[f] || ['tags'];
      for (const k of Object.keys(v.details)) if (!allowed.includes(k)) err(`${p}/details/${k}`, `not allowed for factor ${f}`);
    }
  }

  if (profile.scope.mode === 'tasks' && !profile.scope.taskIds) err('/scope/taskIds', 'is required when mode is "tasks"');
  if (profile.scope.mode === 'all-tasks' && profile.scope.taskIds) err('/scope/taskIds', 'must be absent when mode is "all-tasks"');
  if (profile.stage === 'planning' && profile.previousAssessmentId !== undefined) err('/previousAssessmentId', 'only verification profiles reference a previous assessment');
  if (profile.stage === 'verification' && !profile.evidence.some((e) => e.kind === 'diff')) {
    err('/evidence', 'verification profile must link the actual diff (diff evidence)');
  }
  return errors;
}

// ------------------------------------------------------------------ config
export function configErrors(config) {
  const errors = structuralErrors('config', config);
  if (errors.length) return errors;
  const err = (path, message) => errors.push({ path, message });

  const uniq = (list, path, keyFn = (x) => x.id) => {
    const seen = new Map();
    list.forEach((x, i) => {
      const k = keyFn(x);
      if (seen.has(k)) err(`${path}/${i}/id`, `duplicate id "${k}" (also at ${path}/${seen.get(k)})`);
      seen.set(k, i);
    });
    return seen;
  };
  const harnesses = uniq(config.harnesses, '/harnesses');
  const pricing = uniq(config.pricing, '/pricing');
  const pools = uniq(config.quotaPools, '/quotaPools');
  uniq(config.models, '/models');
  const cands = new Map();
  config.models.forEach((m, i) => {
    const key = `${m.harness}/${m.modelId}`;
    if (cands.has(key)) err(`/models/${i}/modelId`, `candidate ${key} is defined twice (also /models/${cands.get(key)})`);
    cands.set(key, i);
  });

  const rules = config.complexityRules;
  for (const [q, t] of Object.entries(rules.volumeThresholds)) {
    for (let i = 1; i < t.length; i++) if (t[i] <= t[i - 1]) err(`/complexityRules/volumeThresholds/${q}/${i}`, 'thresholds must be strictly ascending');
  }
  const cats = rules.workloadCategories.map((c) => c.id);
  uniq(rules.workloadCategories, '/complexityRules/workloadCategories');
  rules.workloadCategories.forEach((c, i) => {
    if (i > 0 && c.upToBp <= rules.workloadCategories[i - 1].upToBp) err(`/complexityRules/workloadCategories/${i}/upToBp`, 'must be strictly ascending');
  });
  const last = rules.workloadCategories[rules.workloadCategories.length - 1];
  if (last && last.upToBp !== 10000) err(`/complexityRules/workloadCategories/${rules.workloadCategories.length - 1}/upToBp`, 'last category must cover 10000');
  for (const mode of ['api', 'subscription', 'timeMinutes']) {
    for (const phase of ['apply', 'verify']) {
      const map = config.workloads[mode][phase];
      for (const c of cats) if (!(c in map)) err(`/workloads/${mode}/${phase}/${c}`, 'is required for every workload category');
      for (const c of Object.keys(map)) if (!cats.includes(c)) err(`/workloads/${mode}/${phase}/${c}`, `unknown workload category "${c}"`);
      for (const c of cats) {
        const r = map[c];
        if (!r) continue;
        const val = (x) => (typeof x === 'number' ? x : Object.entries(x).filter(([k]) => k !== 'toolCalls' && k !== 'peakContextTokens').reduce((s, [, v]) => s + v, 0));
        if (val(r.low) > val(r.typical) || val(r.typical) > val(r.high)) err(`/workloads/${mode}/${phase}/${c}`, 'scenarios must satisfy low <= typical <= high');
      }
    }
  }

  for (const phase of ['apply', 'verify']) {
    const floors = config.phases[phase].qualityFloors;
    if (floors[0].fromDemandBp !== 0) err(`/phases/${phase}/qualityFloors/0/fromDemandBp`, 'first floor must start at 0');
    for (let i = 1; i < floors.length; i++) if (floors[i].fromDemandBp <= floors[i - 1].fromDemandBp) err(`/phases/${phase}/qualityFloors/${i}/fromDemandBp`, 'must be strictly ascending');
  }

  config.models.forEach((m, i) => {
    const p = `/models/${i}`;
    if (!harnesses.has(m.harness)) err(`${p}/harness`, `unknown harness "${m.harness}"`);
    const supported = new Set(m.supportedEfforts);
    (m.efforts || []).forEach((e, j) => {
      if (!supported.has(e)) err(`${p}/efforts/${j}`, `effort "${e}" is not in supportedEfforts of ${m.harness}/${m.modelId}; it is not substituted silently`);
    });
    if (m.api.pricingId !== null && !pricing.has(m.api.pricingId)) err(`${p}/api/pricingId`, `unknown pricing "${m.api.pricingId}"`);
    if (m.subscription.poolId !== null) {
      if (!pools.has(m.subscription.poolId)) err(`${p}/subscription/poolId`, `unknown quota pool "${m.subscription.poolId}"`);
      else {
        const pool = config.quotaPools[pools.get(m.subscription.poolId)];
        if (pool.harness !== m.harness) err(`${p}/subscription/poolId`, `pool "${pool.id}" belongs to harness ${pool.harness}`);
      }
    }
    for (const phase of ['apply', 'verify']) {
      const c = m.coefficients[phase];
      const checkCoef = (cp, coef) => {
        if ((coef.value === null) !== (coef.status === 'unknown')) err(cp, 'value must be null exactly when status is "unknown"');
        if (coef.status === 'measured' && !(coef.sources && coef.sources.length)) err(`${cp}/sources`, 'measured coefficient requires benchmark sources');
        if (coef.inheritedFrom && coef.status === 'measured') err(`${cp}/status`, 'an inherited coefficient cannot be measured for the new model; use proxy or user-override');
      };
      for (const f of FACTOR_IDS) checkCoef(`${p}/coefficients/${phase}/base/${f}`, c.base[f]);
      for (const e of Object.keys(c.effortDelta || {})) if (!supported.has(e)) err(`${p}/coefficients/${phase}/effortDelta/${e}`, `effort "${e}" is not supported`);
      for (const [e, map] of Object.entries(c.byEffort || {})) {
        if (!supported.has(e)) err(`${p}/coefficients/${phase}/byEffort/${e}`, `effort "${e}" is not supported`);
        for (const [f, coef] of Object.entries(map)) checkCoef(`${p}/coefficients/${phase}/byEffort/${e}/${f}`, coef);
      }
      for (const [k, sect] of [['api', m.api.usageMultiplierBp], ['subscription', m.subscription.loadMultiplierBp], ['time', m.time.multiplierBp]]) {
        for (const e of Object.keys(sect[phase])) if (!supported.has(e)) err(`${p}/${k}/${k === 'api' ? 'usageMultiplierBp' : k === 'subscription' ? 'loadMultiplierBp' : 'multiplierBp'}/${phase}/${e}`, `effort "${e}" is not supported`);
      }
    }
  });
  config.quotaPools.forEach((pool, i) => {
    if (!harnesses.has(pool.harness)) err(`/quotaPools/${i}/harness`, `unknown harness "${pool.harness}"`);
    if (pool.observation && pool.conversion && pool.observation.unit !== pool.conversion.unit) {
      err(`/quotaPools/${i}/conversion/unit`, 'conversion unit must match observation unit');
    }
  });
  return errors;
}

// ------------------------------------------------------------------ benchmarks
function measurementKey(r) {
  return [r.benchmark.name, r.benchmark.version, r.model.modelId, r.model.harness, r.model.effort, r.metric].join('\u0000');
}

export function benchmarksErrors(bench) {
  const errors = structuralErrors('benchmarks', bench);
  if (errors.length) return errors;
  const err = (path, message) => errors.push({ path, message });
  const ids = new Map();
  const keys = new Map();
  bench.records.forEach((r, i) => {
    if (ids.has(r.id)) err(`/records/${i}/id`, `duplicate record id "${r.id}"`);
    ids.set(r.id, i);
    const k = measurementKey(r);
    if (keys.has(k)) err(`/records/${i}`, `duplicates measurement of /records/${keys.get(k)} (same benchmark version, model, harness, effort and metric); one measurement must not gain weight by repetition`);
    keys.set(k, i);
  });
  const mids = new Map();
  const mkeys = new Map();
  bench.mappings.forEach((m, i) => {
    if (mids.has(m.id)) err(`/mappings/${i}/id`, `duplicate mapping id "${m.id}"`);
    mids.set(m.id, i);
    const k = [m.benchmark.name, m.benchmark.version, m.metric, m.phase, m.factor].join('\u0000');
    if (mkeys.has(k)) err(`/mappings/${i}`, `duplicates mapping /mappings/${mkeys.get(k)}`);
    mkeys.set(k, i);
  });
  return errors;
}

// Coefficient provenance against the benchmark snapshot.
export function provenanceErrors(config, bench) {
  const errors = [];
  const err = (path, message) => errors.push({ path, message });
  const records = new Map(bench.records.map((r) => [r.id, r]));
  const findMapping = (r, phase, factor) => bench.mappings.find((m) => m.benchmark.name === r.benchmark.name
    && m.benchmark.version === r.benchmark.version && m.metric === r.metric && m.phase === phase && m.factor === factor);

  config.models.forEach((model, i) => {
    for (const phase of ['apply', 'verify']) {
      const entries = [];
      for (const f of FACTOR_IDS) entries.push([`/models/${i}/coefficients/${phase}/base/${f}`, f, null, model.coefficients[phase].base[f]]);
      for (const [e, map] of Object.entries(model.coefficients[phase].byEffort || {})) {
        for (const [f, coef] of Object.entries(map)) entries.push([`/models/${i}/coefficients/${phase}/byEffort/${e}/${f}`, f, e, coef]);
      }
      for (const [path, factor, effort, coef] of entries) {
        const srcs = [];
        for (const [j, id] of (coef.sources || []).entries()) {
          const r = records.get(id);
          if (!r) { err(`${path}/sources/${j}`, `unknown benchmark record "${id}"`); continue; }
          srcs.push(r);
          const mapping = findMapping(r, phase, factor);
          if (!mapping) {
            err(`${path}/sources/${j}`, `no mapping from ${r.benchmark.name} ${r.benchmark.version} (${r.metric}) to ${phase}/${factor}; incompatible benchmark sets need an explicit mapping`);
            continue;
          }
          if (coef.status === 'measured') {
            if (r.source.kind !== 'independent') err(`${path}/status`, `record "${id}" is a provider claim, not an independent measurement`);
            if (mapping.relation !== 'direct') err(`${path}/status`, `mapping "${mapping.id}" is a proxy; label the coefficient proxy`);
            if (r.model.modelId !== model.modelId || r.model.harness !== model.harness) {
              err(`${path}/status`, `record "${id}" measures ${r.model.harness}/${r.model.modelId}, not this candidate; label it proxy`);
            }
            if (effort !== null && r.model.effort !== effort) err(`${path}/status`, `record "${id}" was measured at effort ${r.model.effort}, not ${effort}`);
          }
        }
        const seen = new Map();
        srcs.forEach((r) => {
          const k = measurementKey(r);
          if (seen.has(k)) err(`${path}/sources`, `records "${seen.get(k)}" and "${r.id}" are the same measurement`);
          seen.set(k, r.id);
        });
      }
    }
  });
  return errors;
}

export function assertValid(label, errors) {
  if (errors.length) throw new ValidationError(label, errors.sort((a, b) => compareCodeUnits(a.path, b.path)));
}

export { ValidationError };
