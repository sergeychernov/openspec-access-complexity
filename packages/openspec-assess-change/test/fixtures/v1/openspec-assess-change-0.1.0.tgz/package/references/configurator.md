# Локальный конфигуратор

```bash
node bin/openspec-assess.mjs configure            # свободный порт на 127.0.0.1
node bin/openspec-assess.mjs configure --port 4317
```

CLI печатает адрес (`http://127.0.0.1:<port>/configurator/index.html`). Остановка — `Ctrl+C` (SIGINT/SIGTERM закрывают сервер).

## Что можно делать

- **Матрица «параметр × модель»** с переключателем Apply/Verify: коэффициент каждой модели по каждому фактору (пусто = unknown), вес фактора в фазе, статус происхождения (measured/proxy/heuristic/user-override/unknown), basis и источники во всплывающей подсказке, якоря rubric в заголовке строки.
- **Модель**: `modelId` (ручная смена версии → унаследованные коэффициенты помечаются `proxy` + `inheritedFrom`), enabled, доступность для аккаунта, набор efforts, сброс к defaults.
- **API**: валюта, веса quality/economy/time, якоря нормализации, тарифы каждой модели (микроединицы за 1M токенов), статус цены, учёт reasoning.
- **Subscription**: веса и якоря, quota pools (участники, наблюдение остатка, преобразование нагрузки в единицы квоты).
- **Ограничения**: минимальный контекст, API-бюджет, обязательные capabilities, пороги качества по фазам.
- **Advanced**: любое поле конфигурации через JSON overrides.
- **Preview**: четыре рейтинга через тот же pure evaluator, что и CLI (байты отчёта совпадают с CLI — `test/configurator.test.mjs`), Δ позиции относительно baseline, изменение статуса и порога.
- **Ошибки схемы** отображаются списком с путями полей; некорректное значение не применяется молча.
- **Import/export**: профиль и overrides выбираются файлами; результат скачивается как `overrides.json`. Исходные файлы не перезаписываются — у сервера нет записывающего API.

## Безопасность и offline

Сервер (`src/node/server.mjs`) слушает только loopback, принимает только GET/HEAD, отвечает 421 на чужой `Host` (защита от DNS rebinding) и отдаёт файлы из allowlist (`configurator/`, `src/core/`, `config/`, `schemas/`, `examples/golden/`) с CSP `default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'`. Нет CDN, внешних шрифтов, аналитики, login и вызовов моделей — страница работает без сети.
