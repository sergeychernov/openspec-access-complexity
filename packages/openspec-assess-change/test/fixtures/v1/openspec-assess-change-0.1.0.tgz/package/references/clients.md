# Подключение к Codex, Claude Code и Antigravity IDE

Один пакет — один `SKILL.md`, один evaluator и одни defaults. Различается только место, где клиент ищет skills. Копии не форкаются: во всех клиентах должны совпадать `version identity` и digest `SKILL.md` (`openspec-assess version`).

## Где клиенты ищут skills (проверено 2026-11-14)

| Клиент | Проект | Пользователь | Symlink | Как посмотреть список |
| --- | --- | --- | --- | --- |
| Codex (CLI, IDE, app) | `.agents/skills/<name>/` в каждом каталоге от cwd до корня репозитория | `$HOME/.agents/skills/` | поддерживается, цель symlink сканируется | `/skills` или `$` в CLI/IDE |
| Claude Code | `.claude/skills/<name>/` (также в родительских каталогах до корня репозитория) | `~/.claude/skills/` | поддерживается для project/personal | `/skills`, меню `/` |
| Antigravity (App, CLI, IDE) | `.agents/skills/<name>/` (а также legacy `.agent/skills`) в workspace и родителях до корня репозитория | `~/.gemini/config/skills/` | не описан в документации | IDE: Customizations в боковой панели агента |

Источники: [Codex — Build skills](https://learn.chatgpt.com/docs/build-skills), [Claude Code — Skills](https://code.claude.com/docs/en/skills), [Antigravity — Skills](https://antigravity.google/docs/skills). Codex требует в frontmatter `name` и `description`; Claude Code и Antigravity используют `description` (имя по умолчанию — имя каталога). `SKILL.md` пакета содержит оба поля, имя совпадает с каталогом `openspec-assess-change`.

## Установка в проект

```bash
node packages/openspec-assess-change/scripts/install-skill.mjs --project . --clients codex,claude-code,antigravity
```

Скрипт создаёт `.agents/skills/openspec-assess-change` (Codex и Antigravity) и `.claude/skills/openspec-assess-change` → `../../.agents/skills/openspec-assess-change` — та же схема, что использует `openspec init` для своих skills. По умолчанию `.agents/skills/...` — symlink на каталог пакета; `--mode copy` копирует файлы пакета (для Antigravity, если symlink не подхватывается, и для переноса без исходного пакета). Существующий каталог с другим содержимым не перезаписывается без `--force`.

Generated skills OpenSpec (`openspec-*`) не изменяются.

## Smoke discovery без платного inference

```bash
node packages/openspec-assess-change/scripts/install-skill.mjs --project . --check
```

Проверка на уровне файловой системы: для каждого клиента находит `SKILL.md` в его каталоге discovery (через symlink), проверяет frontmatter и запускает `bin/openspec-assess.mjs version --json` **из этого расположения**; digest `SKILL.md` и version identity должны совпасть у всех трёх. Модели не вызываются.

Затем — ручная проверка в самих клиентах. Используйте только просмотр списка skills и не отправляйте сообщений агенту: документация клиентов явно не утверждает, что просмотр списка обходится без запроса к модели, но сам он задачу не запускает.

1. Codex: `codex` → `/skills` — в списке `openspec-assess-change`.
2. Claude Code: `/skills` — в списке `openspec-assess-change`.
3. Antigravity IDE: Customizations → Skills — `openspec-assess-change`; при отсутствии повторите установку с `--mode copy`.

Результат этой ручной проверки для конкретных версий клиентов фиксируется в README (раздел «Проверено в клиентах»).
