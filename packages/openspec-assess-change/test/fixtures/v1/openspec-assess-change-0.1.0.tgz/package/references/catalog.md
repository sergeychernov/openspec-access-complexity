# Каталог моделей и происхождение коэффициентов

`config/defaults.json` генерируется скриптом `scripts/build-defaults.mjs` из компактных таблиц с комментариями; `npm run check` проверяет, что файл совпадает с генератором. Версии закреплены: автоматического «latest» нет, новая версия появляется только при ручном изменении.

## Стартовый каталог (проверено 2026-11-14)

| Harness | Семейство | Версия | modelId / client ID | Efforts | Контекст | Статус идентичности |
| --- | --- | --- | --- | --- | --- | --- |
| codex | Astra | GPT-6 Astra | `gpt-6-astra` | low, medium, high, xhigh, max | 1.05M | confirmed |
| codex | Sol | GPT-6.1 Sol | `gpt-6.1-sol` | low…max | 1.05M | confirmed |
| codex | Terra | GPT-6.1 Terra | `gpt-6.1-terra` | low…max | 1.05M | confirmed (Codex CLI ≥ 0.159.0) |
| codex | Luna | GPT-6 Luna | `gpt-6-luna` | low…max | 1.05M | confirmed |
| claude-code | Opus | Claude Opus 5.5 | `claude-opus-5-5` | low, medium, high, xhigh, max | 1M | confirmed |
| claude-code | Sonnet | Claude Sonnet 5.5 | `claude-sonnet-5-5` | low…max | 1M | confirmed |
| claude-code | Haiku | Claude Haiku 5.5 | `claude-haiku-5-5` | low…max | 1M | confirmed |
| antigravity | Argon | Gemini 4 Argon | catalog key `gemini-4-argon`, client ID — null | low, medium, high | — | unconfirmed |
| antigravity | Hydrogen | Gemini 4 Hydrogen | catalog key `gemini-4-hydrogen`, client ID — null | low, medium, high, xhigh («Extra») | — | unconfirmed |
| antigravity | Flash | Gemini 3.8 Flash | catalog key `gemini-3.8-flash`, client ID — null | low, medium, high | — | unconfirmed |

Источники: [OpenAI models](https://developers.openai.com/api/docs/models), [Codex models](https://learn.chatgpt.com/docs/models), [Claude models overview](https://platform.claude.com/docs/en/about-claude/models/overview), [Claude Code model configuration](https://code.claude.com/docs/en/model-config), [Antigravity models](https://antigravity.google/docs/models).

Примечания:

- Для Codex в каталог входят значения effort из API-документации от `low` до `max`; `none` и Codex-уровень `ultra` не включены, так как страница Codex не даёт их списка по моделям.
- Antigravity не публикует идентификаторы моделей (страница отсылает к `agy models`), поэтому `clientModelId` равен `null` и не синтезируется из display name. `modelId` здесь — ключ каталога.
- Публичная доступность ≠ доступность аккаунту: `availability` по умолчанию `unknown`, и такой кандидат остаётся `provisional`. Укажите `available`/`unavailable` в overrides (см. `examples/demo-project/.../assessment/overrides.json`).

## Коэффициенты и их статусы

| Статус | Значение |
| --- | --- |
| `measured` | независимая запись benchmark для **этого** кандидата и effort с mapping `direct` на фазу/фактор (в поставке таких нет) |
| `proxy` | связанное, но не прямое измерение (mapping `proxy`) или значение, унаследованное от прежней версии модели |
| `heuristic` | политика, описанная в `basis`, без сопоставимого измерения |
| `unknown` | значения нет (`value: null`); не равно нулю |
| `user-override` | задано пользователем, исходный `basis` сохраняется в тексте |

Поставляемые значения:

- База — **tier** позиционирования внутри линейки вендора (`frontier`, `strong`, `balanced`, `economy`): apply 8200/7600/6800/5800, verify 8000/7200/6400/5400; на «глубоких» факторах (`architecture`, `logic`, `consequences`, `uncertainty`) нижние tiers теряют 200/400/600. Это эвристика, а не результат измерения.
- Effort-дельты относительно `medium`: low −800, high +300, xhigh +500, max +600 — единая эвристика.
- Для шести кандидатов, у которых есть независимый индекс Artificial Analysis Coding Agent Index v2.1, apply-коэффициенты факторов `volume`, `domains`, `layers`, `architecture`, `logic` помечены `proxy` со ссылкой на запись: значение остаётся tier-эвристикой, а индекс подтверждает порядок tiers внутри harness (`test/catalog.test.mjs`). Verify-коэффициенты — `heuristic`: сопоставимого независимого измерения проверки нет.
- Ресурсы: множители usage/нагрузки/времени по effort и tier — сценарные эвристики (`api.basis`, `subscription.basis`, `time.basis`).
- Политики фаз (`phases.*.relevanceWeights`, `qualityFloors`, `criticalFactors`) и выбора (`selection`: качество 7, экономия 3, время 0) описаны в их `basis` и являются публичной политикой, не benchmark-фактом.

## Пользовательские overrides

Порядок: `config/defaults.json` ← явный `--overrides <file>` (или `<changeRoot>/assessment/overrides.json`). Merge идёт по известным ключам схемы, списки с `id` — по `id`. Отсутствующее поле наследуется; явные `0`, `false` и `null` — значения. Неизвестный ключ — ошибка с путём, а не молчаливое игнорирование. Effective config целиком валидируется и сохраняется в snapshot каждого run.

## Как обновить модель (ручная процедура)

1. Проверьте новую версию на первичной странице вендора: точный ID, efforts, контекст, цену.
2. Для локальной замены создайте override:
   ```json
   { "kind": "openspec-assess.overrides", "schemaVersion": 1,
     "set": { "models": [ { "id": "codex.sol", "modelId": "gpt-6.2-sol", "displayName": "GPT-6.2 Sol" } ] } }
   ```
   Коэффициенты, не заданные явно, переносятся со статусом `proxy` и `inheritedFrom` (прежние modelId/harness/status), `identity.status` становится `unconfirmed`, старый `clientModelId` сбрасывается. Прежнее измерение не приписывается новой версии.
3. Задайте известные коэффициенты явно (они станут `user-override`) или добавьте benchmark-записи и mapping (см. [benchmarks.md](benchmarks.md)).
4. Для изменения поставки: правьте таблицы в `scripts/build-defaults.mjs`, запустите `npm run defaults && npm test`.

Прежние assessment snapshots не меняются: каждый run хранит свой `config.snapshot.json`, а replay использует только его.
