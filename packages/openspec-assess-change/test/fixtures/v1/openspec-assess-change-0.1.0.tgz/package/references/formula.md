# Формула расчёта (evaluator 1, normalization 1)

Все величины — целые числа: коэффициенты, веса, индексы и utility в basis points 0–10000, деньги — микроединицы валюты. Произведения и деления идут через BigInt с одним правилом округления — **вниз** (`floor`). NaN, Infinity, дробные числа и дублирующиеся JSON-ключи отклоняются. Ключи сериализуются в порядке UTF-16 code units (не `localeCompare`), поэтому вывод не зависит от locale, часового пояса, порядка ключей и клиента.

## Порядок

1. Проверить profile, effective config, benchmark snapshot, provenance коэффициентов и `asOf`.
2. Свойства change (только profile + `complexityRules`): уровни факторов, индексы `volume`/`complexity`/`risk`/`uncertainty`, категория нагрузки (`xs`…`xl`) для low/typical/high, требование к качеству `demand = max(upper(complexity), upper(risk))`.
3. Для каждой фазы (`apply`, `verify`) и режима (`api`, `subscription`) развернуть enabled model + harness во все разрешённые effort (`efforts` ⊆ `supportedEfforts`; неподдерживаемый effort — ошибка конфигурации).
4. Ограничения: `enabled`, `availability`, `minContextTokens`, `requiredCapabilities`, API-бюджет, известная нехватка квоты. Нарушение → исключение; неизвестное значение для обязательного ограничения → `provisional`.
5. Пригодность, порог качества, критические факторы, ресурсы, utility.
6. Сортировка вариантов, выбор одного effort на кандидата, четыре списка, trace.

## Пригодность (heuristic fit score)

Для применимых факторов с уровнем `d_i` (для `unknown` — консервативный уровень), весом фазы `w_i` и коэффициентом модели `c_i`:

```
r_i = w_i × max(1, d_i)
F   = floor( Σ r_i × c_i / Σ r_i )        (только по r_i > 0)
```

- `not-applicable` исключается; неизвестный активный `c_i` не заменяется нулём: `F` не вычисляется, показываются известные вклады и `coverage = floor(10000 × Σ r_known / Σ r)`, кандидат — `provisional`.
- `Σ r = 0` (все применимые веса фазы нулевые) → рейтинг `undefined`, список не строится.
- Коэффициент варианта: `byEffort[effort][factor]`, иначе `base[factor] + effortDelta[effort]` (с отсечением в 0…10000).
- Порог качества: последний `qualityFloors[k]` с `fromDemandBp ≤ demand`. `F < floor` → `below-threshold`.
- Критические факторы (`criticalFactors`): если верхняя граница уровня ≥ `whenLevelAtLeast`, коэффициент должен быть ≥ `minCoefficientBp`; иначе `below-threshold` (низкая цена этого не компенсирует), неизвестный коэффициент → `provisional`.

`F` — эвристическая оценка соответствия, **не вероятность успеха**.

## Utility

Нормализация с фиксированными якорями из config (не из минимума/максимума кандидатов, поэтому добавление кандидата не меняет баллы остальных):

```
N(x, anchor) = min(10000, floor(10000 × x / anchor))
U = floor( (q·F + e·(10000 − N(resource_high)) + t·(10000 − N(time_high))) / (q + e + t) )
```

`resource_high` — верхний сценарий стоимости (API, микроединицы) или относительной нагрузки (subscription). Веса `q/e/t` и якоря задаются отдельно для API и subscription (`selection.api`, `selection.subscription`). Слагаемое с нулевым весом не требуется. Если нужная экономическая величина неизвестна, `U` не вычисляется (`economicComplete: false`), нулевая стоимость не подставляется.

## Сортировка

Группы: `eligible` → `provisional` → `below-threshold`; исключённые — отдельным списком по ID.

- `eligible`: сначала с полной utility — по убыванию `U`, затем `F`, затем по возрастанию `resource_high`; потом с неполными экономическими данными — по убыванию `F`.
- `provisional`: сначала с известным `F` (по убыванию), затем без `F`.
- `below-threshold`: по убыванию известного `F`.
- Последний ключ всегда — candidate ID (`harness/modelId`), затем effort, в порядке code units.

Рекомендуемый effort кандидата — первый его вариант по тем же правилам. Статус рейтинга: `ok` (есть eligible; первый — вершина списка для ручного выбора), `provisional-only` (ничего не подтверждено, рекомендации нет), `no-suitable`, `undefined`.

## Проверки (tests)

- `test/ranking.test.mjs` — исключения, effort, контекст, раздельные матрицы, unknown/not-applicable, некомпенсируемые ограничения, независимость от постороннего кандидата, ties, неполная экономика, статусы, trace и отсутствие заявлений о вероятности; golden/metamorphic: одинаковые байты, изменение verify-весов не трогает apply, снижение расхода не уменьшает utility.
- `test/contracts.test.mjs` — canonical bytes при перестановке ключей, независимость от locale/TZ, целочисленная арифметика.
- `examples/golden/` — эталонный отчёт публичного примера; `node examples/run-example.mjs` сверяет его.
