// Browser UI for the configurator. All calculation goes through configurator/model.mjs → src/core.
import {
  effectiveFrom, exportOverrides, preview, matrix, setCoefficient, setPath, setModelField, resetToDefaults, compareReports, parseIntOrNull, reportBytes,
} from './model.mjs';
import { parseJsonStrict, canonicalStringify, RANKING_KEYS, formatMicros, RUBRIC } from '../src/core/index.mjs';

const $ = (id) => document.getElementById(id);
const el = (tag, attrs = {}, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (k === 'text') n.textContent = v;
    else if (k === 'style') n.style.cssText = v; // CSSOM: allowed under the strict style-src CSP
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k !== null && k !== undefined) n.append(k.nodeType ? k : document.createTextNode(String(k)));
  return n;
};

const state = {
  defaults: null, benchmarks: null, profile: null, start: null, edited: null, phase: 'apply',
  asOf: null, baseline: null, last: null, inputErrors: [], startLabel: 'shipped defaults',
};

async function fetchJson(path) {
  const r = await fetch(path, { cache: 'no-store' });
  if (!r.ok) throw new Error(`${path}: HTTP ${r.status}`);
  return parseJsonStrict(await r.text(), path);
}

function setStatus(text, kind = 'ok') {
  const s = $('status');
  s.textContent = text;
  s.className = `status ${kind}`;
}

function showErrors(errors) {
  const list = $('errors');
  list.replaceChildren(...errors.map((e) => el('li', { text: `${e.path}: ${e.message}` })));
  $('errors-panel').hidden = errors.length === 0;
}

// ------------------------------------------------------------------ editing helpers
function update(next) {
  state.edited = next;
  recompute();
  render();
}

function intInput({ value, onChange, label, width = null, placeholder = 'unknown' }) {
  const input = el('input', {
    type: 'text', inputmode: 'numeric', value: value === null || value === undefined ? '' : String(value), placeholder, 'aria-label': label, style: width ? `width:${width}px` : null,
  });
  input.addEventListener('change', () => {
    const v = parseIntOrNull(input.value);
    if (Number.isNaN(v)) {
      state.inputErrors = [{ path: label, message: `"${input.value}" is not an integer` }];
      showErrors(state.inputErrors);
      setStatus('Input rejected: not an integer', 'err');
      return;
    }
    state.inputErrors = [];
    onChange(v);
  });
  return input;
}

const badge = (status) => el('span', { class: `badge s-${status}`, text: status });

// ------------------------------------------------------------------ matrix
function renderMatrix() {
  const cfg = state.edited;
  const rows = matrix(cfg, state.phase);
  const startRows = matrix(state.start, state.phase);
  const head = el('tr', {}, el('th', { text: 'Factor' }), el('th', { text: `${state.phase} weight` }),
    ...cfg.models.map((m) => {
      const supported = m.supportedEfforts;
      const active = new Set(m.efforts || supported);
      return el('th', { class: 'model', scope: 'col' },
        el('div', { text: m.displayName }),
        el('div', { class: 'muted', text: `${m.harness} · ${m.identity.status}` }),
        el('label', {}, 'modelId', (() => {
          const i = el('input', { type: 'text', value: m.modelId, 'aria-label': `${m.id} modelId`, style: 'width:120px' });
          i.addEventListener('change', () => update(setModelField(state.edited, m.id, 'modelId', i.value.trim())));
          return i;
        })()),
        el('label', { style: 'flex-direction:row;gap:4px;align-items:center' }, (() => {
          const c = el('input', { type: 'checkbox', checked: m.enabled, 'aria-label': `${m.id} enabled` });
          c.addEventListener('change', () => update(setModelField(state.edited, m.id, 'enabled', c.checked)));
          return c;
        })(), 'enabled'),
        (() => {
          const s = el('select', { 'aria-label': `${m.id} availability` }, ...['available', 'unknown', 'unavailable'].map((a) => el('option', { value: a, selected: m.availability === a, text: a })));
          s.addEventListener('change', () => update(setModelField(state.edited, m.id, 'availability', s.value)));
          return s;
        })(),
        el('div', { class: 'efforts' }, ...supported.map((e) => {
          const c = el('input', { type: 'checkbox', checked: active.has(e), 'aria-label': `${m.id} effort ${e}` });
          c.addEventListener('change', () => {
            const cur = new Set(state.edited.models.find((x) => x.id === m.id).efforts || supported);
            if (c.checked) cur.add(e); else cur.delete(e);
            const list = supported.filter((x) => cur.has(x));
            update(setModelField(state.edited, m.id, 'efforts', list.length === supported.length ? [] : list));
          });
          return el('label', {}, c, e);
        })),
        el('button', { type: 'button', class: 'small', onclick: () => update(resetToDefaults(state.edited, state.defaults, { models: [m.id] })), text: 'reset' }));
    }));
  const body = rows.map((row, ri) => el('tr', {},
    el('th', { scope: 'row', title: RUBRIC[row.factor].anchors.map((a, i) => `${i}: ${a}`).join('\n'), text: `${RUBRIC[row.factor].title} (${row.factor})` }),
    el('td', {}, intInput({
      value: row.weight, label: `/phases/${state.phase}/relevanceWeights/${row.factor}`, width: 44, placeholder: '0',
      onChange: (v) => update(setPath(state.edited, `/phases/${state.phase}/relevanceWeights/${row.factor}`, v === null ? 0 : v)),
    })),
    ...row.cells.map((c, ci) => {
      const before = startRows[ri].cells[ci];
      const tip = [`${c.status}: ${c.basis}`, c.sources.length ? `sources: ${c.sources.join(', ')}` : null, c.inheritedFrom ? `inherited from ${c.inheritedFrom.harness}/${c.inheritedFrom.modelId} (${c.inheritedFrom.status})` : null].filter(Boolean).join('\n');
      return el('td', { class: before && before.value !== c.value ? 'edited' : null, title: tip },
        intInput({ value: c.value, label: `${c.modelId} ${state.phase} ${row.factor}`, onChange: (v) => update(setCoefficient(state.edited, c.modelId, state.phase, row.factor, v)) }),
        badge(c.status));
    })));
  $('matrix').replaceChildren(el('thead', {}, head), el('tbody', {}, ...body));
}

// ------------------------------------------------------------------ resources and selection
function kvInputs(entries) {
  return el('div', { class: 'kv' }, ...entries.map(([label, path, value]) => el('label', {}, label, intInput({ value, label: path, onChange: (v) => update(setPath(state.edited, path, v)) }))));
}

function renderResources() {
  const cfg = state.edited;
  const api = cfg.selection.api;
  const sub = cfg.selection.subscription;
  const currency = el('input', { type: 'text', value: api.currency, 'aria-label': '/selection/api/currency', style: 'width:60px' });
  currency.addEventListener('change', () => update(setPath(state.edited, '/selection/api/currency', currency.value.trim().toUpperCase())));
  $('api-settings').replaceChildren(
    el('div', { class: 'kv' }, el('label', {}, 'currency', currency)),
    kvInputs([
      ['quality weight', '/selection/api/weights/quality', api.weights.quality],
      ['economy weight', '/selection/api/weights/economy', api.weights.economy],
      ['time weight', '/selection/api/weights/time', api.weights.time],
      ['cost anchor (micros)', '/selection/api/anchors/costMicros', api.anchors.costMicros],
      ['time anchor (min)', '/selection/api/anchors/timeMinutes', api.anchors.timeMinutes],
    ]),
  );
  const rateKeys = ['uncachedInput', 'cacheRead', 'cacheWrite', 'output', 'reasoning'];
  $('pricing').replaceChildren(
    el('thead', {}, el('tr', {}, el('th', { text: 'Pricing (micros / 1M tokens)' }), el('th', { text: 'status' }), ...rateKeys.map((k) => el('th', { text: k })), el('th', { text: 'reasoning billed' }), el('th', { text: 'long context' }))),
    el('tbody', {}, ...cfg.pricing.map((p, i) => el('tr', {},
      el('td', { title: p.note || '', text: p.id }),
      el('td', {}, (() => {
        const s = el('select', { 'aria-label': `/pricing/${i}/status` }, ...['confirmed', 'example', 'unknown'].map((x) => el('option', { value: x, selected: p.status === x, text: x })));
        s.addEventListener('change', () => update(setPath(state.edited, `/pricing/${i}/status`, s.value)));
        return s;
      })()),
      ...rateKeys.map((k) => el('td', {}, intInput({ value: p.rates[k], label: `/pricing/${i}/rates/${k}`, width: 80, onChange: (v) => update(setPath(state.edited, `/pricing/${i}/rates/${k}`, v)) }))),
      el('td', {}, (() => {
        const s = el('select', { 'aria-label': `/pricing/${i}/reasoningBilling` }, ...['as-output', 'separate'].map((x) => el('option', { value: x, selected: p.reasoningBilling === x, text: x })));
        s.addEventListener('change', () => update(setPath(state.edited, `/pricing/${i}/reasoningBilling`, s.value)));
        return s;
      })()),
      el('td', { text: p.longContext ? `> ${p.longContext.thresholdTokens}` : '—' })))),
  );
  $('sub-settings').replaceChildren(kvInputs([
    ['quality weight', '/selection/subscription/weights/quality', sub.weights.quality],
    ['economy weight', '/selection/subscription/weights/economy', sub.weights.economy],
    ['time weight', '/selection/subscription/weights/time', sub.weights.time],
    ['load anchor', '/selection/subscription/anchors/load', sub.anchors.load],
    ['time anchor (min)', '/selection/subscription/anchors/timeMinutes', sub.anchors.timeMinutes],
  ]));
  $('pools').replaceChildren(
    el('thead', {}, el('tr', {}, el('th', { text: 'Quota pool' }), el('th', { text: 'members' }), el('th', { text: 'remaining' }), el('th', { text: 'unit' }), el('th', { text: 'observedAt (UTC)' }), el('th', { text: 'max age h' }), el('th', { text: 'units / 1000 load' }), el('th', { text: '' }))),
    el('tbody', {}, ...cfg.quotaPools.map((pool, i) => {
      const o = pool.observation;
      const members = cfg.models.filter((m) => m.subscription.poolId === pool.id).map((m) => m.family).join(', ');
      const text = (field, value, w = 80) => {
        const t = el('input', { type: 'text', value: value ?? '', 'aria-label': `/quotaPools/${i}/observation/${field}`, style: `width:${w}px` });
        t.addEventListener('change', () => update(setPath(state.edited, `/quotaPools/${i}/observation/${field}`, t.value.trim())));
        return t;
      };
      return el('tr', {},
        el('td', { title: pool.note || '', text: pool.label }),
        el('td', { text: members }),
        o ? el('td', {}, intInput({ value: o.remaining, label: `/quotaPools/${i}/observation/remaining`, width: 70, onChange: (v) => update(setPath(state.edited, `/quotaPools/${i}/observation/remaining`, v)) })) : el('td', { class: 'muted', text: 'no observation' }),
        el('td', {}, o ? text('unit', o.unit, 70) : ''),
        el('td', {}, o ? text('observedAt', o.observedAt, 150) : ''),
        el('td', {}, o ? intInput({ value: o.maxAgeHours, label: `/quotaPools/${i}/observation/maxAgeHours`, width: 40, onChange: (v) => update(setPath(state.edited, `/quotaPools/${i}/observation/maxAgeHours`, v)) }) : ''),
        el('td', {}, intInput({
          value: pool.conversion ? pool.conversion.quotaUnitsPer1000Load : null, label: `/quotaPools/${i}/conversion/quotaUnitsPer1000Load`, width: 60, placeholder: 'none',
          onChange: (v) => update(setPath(state.edited, `/quotaPools/${i}/conversion`, v === null ? null : { quotaUnitsPer1000Load: v, unit: o ? o.unit : 'units', source: 'entered in the configurator' })),
        })),
        el('td', {}, el('button', {
          type: 'button',
          onclick: () => update(setPath(state.edited, `/quotaPools/${i}/observation`, o ? null : { observedAt: state.asOf || '2026-01-01T00:00:00Z', maxAgeHours: 24, remaining: 0, unit: 'percent', resetAt: null, source: 'entered in the configurator' })),
          text: o ? 'clear observation' : 'add observation',
        })));
    })),
  );
  const c = cfg.constraints;
  const caps = el('input', { type: 'text', value: c.requiredCapabilities.join(', '), 'aria-label': '/constraints/requiredCapabilities', style: 'width:200px' });
  caps.addEventListener('change', () => update(setPath(state.edited, '/constraints/requiredCapabilities', caps.value.split(',').map((x) => x.trim()).filter(Boolean))));
  const floors = (phase) => {
    const t = el('input', { type: 'text', value: cfg.phases[phase].qualityFloors.map((f) => `${f.fromDemandBp}:${f.floorBp}`).join(' '), 'aria-label': `/phases/${phase}/qualityFloors`, style: 'width:320px' });
    t.addEventListener('change', () => {
      const list = t.value.trim().split(/\s+/).filter(Boolean).map((pair) => pair.split(':').map(Number)).map(([a, b]) => ({ fromDemandBp: a, floorBp: b }));
      update(setPath(state.edited, `/phases/${phase}/qualityFloors`, list));
    });
    return el('label', {}, `${phase} floors (demand:floor bp)`, t);
  };
  $('constraints').replaceChildren(el('div', { class: 'kv' },
    el('label', {}, 'min context tokens', intInput({ value: c.minContextTokens, label: '/constraints/minContextTokens', placeholder: 'none', onChange: (v) => update(setPath(state.edited, '/constraints/minContextTokens', v)) })),
    el('label', {}, 'max API cost (micros)', intInput({ value: c.api.maxCostMicros, label: '/constraints/api/maxCostMicros', placeholder: 'none', onChange: (v) => update(setPath(state.edited, '/constraints/api/maxCostMicros', v)) })),
    el('label', {}, 'required capabilities', caps),
    floors('apply'), floors('verify')));
}

// ------------------------------------------------------------------ preview
function recompute() {
  if (!state.profile) {
    state.last = null;
    $('preview-info').textContent = 'Load a profile to see the four rankings.';
    showErrors(state.inputErrors);
    return;
  }
  const r = preview({ defaults: state.defaults, edited: state.edited, profile: state.profile, benchmarks: state.benchmarks, asOf: state.asOf });
  if (!r.ok) {
    showErrors(r.errors);
    setStatus(`Invalid: ${r.message}`, 'err');
    state.last = null;
    return;
  }
  showErrors(state.inputErrors);
  state.last = r;
  setStatus(`Preview up to date · ${r.overrides.set && Object.keys(r.overrides.set).length ? 'overrides active' : 'defaults only'}`, 'ok');
}

function renderPreview() {
  const box = $('preview');
  if (!state.last) { box.replaceChildren(); return; }
  const { report } = state.last;
  const cmp = compareReports(state.baseline, report);
  $('preview-info').textContent = `Change ${report.change.name} (${report.change.stage}) · demand ${report.properties.demandBp} bp · baseline: ${state.baseline ? 'set' : 'none'}. Δ = rank change against the baseline.`;
  box.replaceChildren(...RANKING_KEYS.map((key) => {
    const r = report.rankings[key];
    const mode = key.split('/')[1];
    const st = cmp[`${key}#status`];
    const fl = cmp[`${key}#floor`];
    return el('section', {},
      el('h3', { text: `${key} — ${r.status}` }),
      el('p', { class: 'small muted', text: `floor ${r.qualityFloorBp} bp${state.baseline && fl.before !== fl.after ? ` (was ${fl.before})` : ''}${state.baseline && st.before !== st.after ? ` · status was ${st.before}` : ''} · weights q${r.selectionWeights.quality}/e${r.selectionWeights.economy}/t${r.selectionWeights.time}` }),
      el('table', {},
        el('thead', {}, el('tr', {}, ...['#', 'Δ', 'candidate', 'effort', 'group', 'fit', 'utility', mode === 'api' ? 'typical cost' : 'typical load'].map((h) => el('th', { text: h })))),
        el('tbody', {}, ...r.candidates.map((c, i) => {
          const d = cmp[key][i];
          const res = mode === 'api'
            ? (c.resource.status === 'known' ? formatMicros(c.resource.typicalMicros, c.resource.currency) : 'unknown')
            : (c.resource.status === 'known' ? `${c.resource.typicalLoad} (${c.resource.capacity.status})` : 'unknown');
          return el('tr', { title: c.reasons.join('\n') },
            el('td', { text: c.rank }),
            el('td', { class: d.delta > 0 ? 'up' : (d.delta < 0 ? 'down' : null), text: d.delta === null ? (state.baseline ? 'new' : '') : (d.delta > 0 ? `+${d.delta}` : d.delta === 0 ? '·' : String(d.delta)) }),
            el('td', { text: c.candidateId }),
            el('td', { text: c.recommendedEffort }),
            el('td', { class: `g-${c.group}`, text: c.group }),
            el('td', { text: c.suitability.valueBp ?? '—' }),
            el('td', { text: c.utilityBp ?? '—' }),
            el('td', { text: res }));
        }))),
      r.excluded.length ? el('p', { class: 'small', text: `Excluded: ${r.excluded.map((e) => `${e.candidateId} (${e.reasons.join('; ')})`).join(', ')}` }) : null);
  }));
}

function render() {
  renderMatrix();
  renderResources();
  renderPreview();
  document.querySelectorAll('[data-phase]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.phase === state.phase)));
}

// ------------------------------------------------------------------ inputs, export, reset
async function readFileJson(input) {
  const f = input.files && input.files[0];
  if (!f) return null;
  return parseJsonStrict(await f.text(), f.name);
}

function startFrom(overrides, label) {
  try {
    state.start = effectiveFrom(state.defaults, overrides);
    state.edited = state.start;
    state.startLabel = label;
    state.baseline = null;
    recompute();
    if (state.last) state.baseline = state.last.report;
    render();
    $('adv').value = canonicalStringify(exportOverrides(state.defaults, state.edited), { pretty: true });
    $('inputs-info').textContent = `Started from ${label}${state.profile ? ` · profile ${state.profile.change.name} (${state.profile.stage})` : ''}. The baseline for Δ is this starting point.`;
  } catch (e) {
    showErrors(e.errors || [{ path: '/', message: e.message }]);
    setStatus('Overrides rejected', 'err');
  }
}

function download(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = el('a', { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function wire() {
  document.querySelectorAll('[data-phase]').forEach((b) => b.addEventListener('click', () => { state.phase = b.dataset.phase; render(); }));
  $('in-profile').addEventListener('change', async (ev) => {
    try {
      state.profile = await readFileJson(ev.target);
      recompute();
      if (!state.baseline && state.last) state.baseline = state.last.report;
      render();
    } catch (e) { showErrors([{ path: '/', message: e.message }]); setStatus('Profile rejected', 'err'); }
  });
  $('in-overrides').addEventListener('change', async (ev) => {
    try { startFrom(await readFileJson(ev.target), ev.target.files[0].name); } catch (e) { showErrors([{ path: '/', message: e.message }]); setStatus('Overrides rejected', 'err'); }
  });
  $('in-asof').addEventListener('change', () => {
    const v = $('in-asof').value.trim();
    state.asOf = v === '' ? null : v;
    recompute();
    render();
  });
  $('btn-example').addEventListener('click', async () => {
    state.profile = await fetchJson('../examples/golden/profile.json');
    $('in-asof').value = '2026-11-14T12:00:00Z';
    state.asOf = '2026-11-14T12:00:00Z';
    startFrom(await fetchJson('../examples/golden/overrides.json'), 'example overrides (examples/golden/overrides.json)');
  });
  $('btn-baseline').addEventListener('click', () => { if (state.last) { state.baseline = state.last.report; render(); } });
  $('btn-reset-all').addEventListener('click', () => update(resetToDefaults(state.edited, state.defaults, { models: state.defaults.models.map((m) => m.id), groups: ['phases', 'selection', 'constraints', 'quotaPools', 'complexityRules', 'workloads'] })));
  $('btn-export').addEventListener('click', () => {
    try {
      download('overrides.json', canonicalStringify(exportOverrides(state.defaults, state.edited), { pretty: true }));
    } catch (e) { showErrors(e.errors || [{ path: '/', message: e.message }]); }
  });
  $('btn-adv-refresh').addEventListener('click', () => { $('adv').value = canonicalStringify(exportOverrides(state.defaults, state.edited), { pretty: true }); });
  $('btn-adv-apply').addEventListener('click', () => {
    try {
      const ov = parseJsonStrict($('adv').value, 'overrides JSON');
      state.edited = effectiveFrom(state.defaults, ov);
      recompute();
      render();
    } catch (e) {
      showErrors(e.errors || [{ path: '/', message: e.message }]);
      setStatus('Overrides JSON rejected', 'err');
    }
  });
}

async function boot() {
  try {
    [state.defaults, state.benchmarks] = await Promise.all([fetchJson('../config/defaults.json'), fetchJson('../config/benchmarks.json')]);
    wire();
    startFrom(null, 'shipped defaults');
    setStatus(state.profile ? 'Ready' : 'Ready — load a profile for the preview', 'ok');
  } catch (e) {
    setStatus(`Failed to load package files: ${e.message}`, 'err');
  }
}

// Exposed for inspection and for the CLI/UI parity check.
window.__configurator = { state, preview, reportBytes, exportOverrides };
boot();
