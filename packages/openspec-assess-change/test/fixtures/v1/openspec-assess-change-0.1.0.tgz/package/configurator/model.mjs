// Configurator model: pure functions shared by the browser UI and the Node tests. It never writes
// files; the UI only offers the result for download (export).
import {
  mergeConfig, diffToOverrides, evaluate, canonicalStringify, clone, FACTOR_IDS, RANKING_KEYS, ValidationError,
} from '../src/core/index.mjs';

export const PHASES = ['apply', 'verify'];

// Effective config for the editor: defaults ← imported overrides.
export function effectiveFrom(defaults, overrides) {
  return mergeConfig(defaults, overrides || null);
}

// The editor works on a full config copy; export turns it back into minimal overrides.
export function exportOverrides(defaults, edited, note = 'exported from the local configurator') {
  const strip = clone(edited);
  delete strip.provenance;
  return diffToOverrides(defaults, strip, note);
}

// Recompute exactly as the CLI does: defaults ← overrides (from the edited state) → evaluate.
export function preview({ defaults, edited, profile, benchmarks, asOf = null }) {
  try {
    const overrides = exportOverrides(defaults, edited);
    const config = mergeConfig(defaults, overrides);
    const report = evaluate({ profile, config, benchmarks, asOf });
    return { ok: true, overrides, config, report, errors: [] };
  } catch (e) {
    if (e instanceof ValidationError || (e && Array.isArray(e.errors))) return { ok: false, errors: e.errors, message: e.message.split('\n')[0] };
    return { ok: false, errors: [{ path: '/', message: e.message }], message: e.message };
  }
}

export function reportBytes(report) {
  return canonicalStringify(report, { pretty: true });
}

// Matrix rows for one phase: factor × model with value, provenance and basis.
export function matrix(config, phase) {
  const models = config.models;
  return FACTOR_IDS.map((factor) => ({
    factor,
    weight: config.phases[phase].relevanceWeights[factor],
    cells: models.map((m) => {
      const c = m.coefficients[phase].base[factor];
      return {
        modelId: m.id, value: c.value, status: c.status, basis: c.basis, sources: c.sources || [], inheritedFrom: c.inheritedFrom || null,
      };
    }),
  }));
}

// Edits (all return a new config; the defaults object is never touched).
export function setCoefficient(config, modelId, phase, factor, value, basis = null) {
  const next = clone(config);
  const m = next.models.find((x) => x.id === modelId);
  const c = m.coefficients[phase].base[factor];
  m.coefficients[phase].base[factor] = value === null
    ? { value: null, status: 'unknown', basis: basis || 'set to unknown in the configurator' }
    : { value, status: 'user-override', basis: basis || `user override in the configurator (was ${c.value === null ? 'unknown' : c.value}, ${c.status})` };
  return next;
}

export function setPath(config, path, value) {
  const next = clone(config);
  const keys = path.split('/').filter(Boolean);
  let node = next;
  for (const k of keys.slice(0, -1)) node = Array.isArray(node) ? node[Number(k)] : node[k];
  const last = keys[keys.length - 1];
  if (Array.isArray(node)) node[Number(last)] = value; else node[last] = value;
  return next;
}

export function setModelField(config, modelId, field, value) {
  const next = clone(config);
  const m = next.models.find((x) => x.id === modelId);
  m[field] = value;
  if (field === 'efforts' && Array.isArray(value) && value.length === 0) delete m.efforts;
  return next;
}

// Reset selected parts to the shipped defaults.
export function resetToDefaults(config, defaults, { models = [], groups = [] } = {}) {
  const next = clone(config);
  for (const id of models) {
    const i = next.models.findIndex((m) => m.id === id);
    const d = defaults.models.find((m) => m.id === id);
    if (i >= 0 && d) next.models[i] = clone(d);
    const pi = next.pricing.findIndex((p) => p.id === `${id}.standard`);
    const dp = defaults.pricing.find((p) => p.id === `${id}.standard`);
    if (pi >= 0 && dp) next.pricing[pi] = clone(dp);
  }
  for (const g of groups) next[g] = clone(defaults[g]);
  return next;
}

// Rank comparison between two reports (for the "what changed" column).
export function compareReports(prev, next) {
  const out = {};
  for (const key of RANKING_KEYS) {
    const before = new Map((prev ? prev.rankings[key].candidates : []).map((c) => [c.candidateId, c]));
    out[key] = next.rankings[key].candidates.map((c) => {
      const b = before.get(c.candidateId);
      return {
        candidateId: c.candidateId,
        rank: c.rank,
        previousRank: b ? b.rank : null,
        delta: b ? b.rank - c.rank : null,
        groupChanged: b ? b.group !== c.group : false,
        utilityDelta: b && b.utilityBp !== null && c.utilityBp !== null ? c.utilityBp - b.utilityBp : null,
      };
    });
    out[`${key}#status`] = { before: prev ? prev.rankings[key].status : null, after: next.rankings[key].status };
    out[`${key}#floor`] = { before: prev ? prev.rankings[key].qualityFloorBp : null, after: next.rankings[key].qualityFloorBp };
  }
  return out;
}

export function parseIntOrNull(text) {
  const t = String(text).trim();
  if (t === '' || t.toLowerCase() === 'unknown') return null;
  if (!/^-?[0-9]+$/.test(t)) return Number.NaN;
  return Number(t);
}
