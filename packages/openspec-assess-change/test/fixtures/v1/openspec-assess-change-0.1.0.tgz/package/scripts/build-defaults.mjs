#!/usr/bin/env node
// Generates config/defaults.json from the compact, documented heuristic tables below.
// Run: node scripts/build-defaults.mjs [--check]
// Every coefficient produced here is status "heuristic" (vendor positioning tiers), never "measured".
// See references/catalog.md and references/formula.md for the rationale of each table.
import { writeFileSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { canonicalStringify } from '../src/core/canonical.mjs';
import { FACTOR_IDS } from '../src/core/factors.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const out = join(here, '..', 'config', 'defaults.json');
const CHECKED = '2026-11-14';

// ---------------------------------------------------------------------------- tiers
// Tier = vendor positioning of the family inside its lineup (flagship / near-flagship / mid / economy).
// It is a policy heuristic, not a benchmark result.
const TIER_BASE = {
  apply: { frontier: 8200, strong: 7600, balanced: 6800, economy: 5800 },
  verify: { frontier: 8000, strong: 7200, balanced: 6400, economy: 5400 },
};
// Per-factor adjustments by tier: lower tiers lose more on factors that require deep reasoning.
const DEEP = ['architecture', 'logic', 'consequences', 'uncertainty'];
const TIER_FACTOR_ADJ = {
  frontier: {},
  strong: Object.fromEntries(DEEP.map((f) => [f, -200])),
  balanced: Object.fromEntries(DEEP.map((f) => [f, -400])),
  economy: Object.fromEntries(DEEP.map((f) => [f, -600])),
};
// Effort deltas relative to the medium/default level (heuristic, same for all families).
const EFFORT_DELTA = { minimal: -1200, low: -800, medium: 0, high: 300, xhigh: 500, extra: 500, max: 600 };
// Usage multiplier (tokens) per effort and subscription load multiplier per tier.
const EFFORT_USAGE = { minimal: 4000, low: 6000, medium: 10000, high: 15000, xhigh: 22000, extra: 22000, max: 30000 };
const TIER_LOAD = { frontier: 20000, strong: 10000, balanced: 7000, economy: 4000 };
const TIER_TIME = { frontier: 13000, strong: 10000, balanced: 7000, economy: 5000 };

// ---------------------------------------------------------------------------- catalog
// Identity data checked on CHECKED against the primary pages in catalog.sources:
// - OpenAI API models + Codex models pages: model IDs, API reasoning efforts, 1.05M context.
//   Codex shows its own level names (Light/Low … Max, Ultra) without a per-model list; the catalog keeps
//   the API-documented values from low to max and leaves out "none" and the Codex-only "ultra".
// - Claude models overview + Claude Code model configuration: IDs, efforts low..max, 1M context.
// - Antigravity models page: efforts (Extra = CLI "xhigh"); client identifiers are not published
//   (the page refers to `agy models`), so clientModelId stays null and identity "unconfirmed".
const OAI_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];
const CLAUDE_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];
const OAI_NOTE = 'Model ID and API reasoning efforts confirmed on the OpenAI models page; Codex availability on the Codex models page. "none" and the Codex-only "ultra" level are not included (no per-model Codex list).';
const CLAUDE_NOTE = 'API ID confirmed on the Claude models overview; efforts low..max and 1M context on the Claude Code model configuration page.';
const AG_NOTE = 'Efforts confirmed on the Antigravity models page. The client identifier is not published there (see `agy models`); modelId is a catalog key, not a client ID, and is not synthesized into clientModelId.';
const MODELS = [
  { id: 'codex.astra', family: 'Astra', displayName: 'GPT-6 Astra', modelId: 'gpt-6-astra', harness: 'codex', clientModelId: 'gpt-6-astra', tier: 'frontier', efforts: OAI_EFFORTS, pool: 'codex-plan', src: ['openai-models', 'codex-models'], ctx: 1050000, status: 'confirmed', note: OAI_NOTE },
  { id: 'codex.sol', family: 'Sol', displayName: 'GPT-6.1 Sol', modelId: 'gpt-6.1-sol', harness: 'codex', clientModelId: 'gpt-6.1-sol', tier: 'strong', efforts: OAI_EFFORTS, pool: 'codex-plan', src: ['openai-models', 'codex-models'], ctx: 1050000, status: 'confirmed', note: OAI_NOTE },
  { id: 'codex.terra', family: 'Terra', displayName: 'GPT-6.1 Terra', modelId: 'gpt-6.1-terra', harness: 'codex', clientModelId: 'gpt-6.1-terra', tier: 'balanced', efforts: OAI_EFFORTS, pool: 'codex-plan', src: ['openai-models', 'codex-models'], ctx: 1050000, status: 'confirmed', note: `${OAI_NOTE} Requires Codex CLI 0.159.0 or later; not listed for the IDE extension.` },
  { id: 'codex.luna', family: 'Luna', displayName: 'GPT-6 Luna', modelId: 'gpt-6-luna', harness: 'codex', clientModelId: 'gpt-6-luna', tier: 'economy', efforts: OAI_EFFORTS, pool: 'codex-plan', src: ['openai-models', 'codex-models'], ctx: 1050000, status: 'confirmed', note: `${OAI_NOTE} Enterprise/Edu administrators must enable Luna first.` },
  { id: 'claude-code.opus', family: 'Opus', displayName: 'Claude Opus 5.5', modelId: 'claude-opus-5-5', harness: 'claude-code', clientModelId: 'claude-opus-5-5', tier: 'frontier', efforts: CLAUDE_EFFORTS, pool: 'claude-plan', src: ['claude-models', 'claude-code-models'], ctx: 1000000, status: 'confirmed', note: CLAUDE_NOTE },
  { id: 'claude-code.sonnet', family: 'Sonnet', displayName: 'Claude Sonnet 5.5', modelId: 'claude-sonnet-5-5', harness: 'claude-code', clientModelId: 'claude-sonnet-5-5', tier: 'strong', efforts: CLAUDE_EFFORTS, pool: 'claude-plan', src: ['claude-models', 'claude-code-models'], ctx: 1000000, status: 'confirmed', note: CLAUDE_NOTE },
  { id: 'claude-code.haiku', family: 'Haiku', displayName: 'Claude Haiku 5.5', modelId: 'claude-haiku-5-5', harness: 'claude-code', clientModelId: 'claude-haiku-5-5', tier: 'economy', efforts: CLAUDE_EFFORTS, pool: 'claude-plan', src: ['claude-models', 'claude-code-models'], ctx: 1000000, status: 'confirmed', note: CLAUDE_NOTE },
  { id: 'antigravity.argon', family: 'Argon', displayName: 'Gemini 4 Argon', modelId: 'gemini-4-argon', harness: 'antigravity', clientModelId: null, tier: 'frontier', efforts: ['low', 'medium', 'high'], pool: 'antigravity-gemini', src: ['antigravity-models'], ctx: null, status: 'unconfirmed', note: `${AG_NOTE} Requires a paid Google AI Pro plan or an eligible trial.` },
  { id: 'antigravity.hydrogen', family: 'Hydrogen', displayName: 'Gemini 4 Hydrogen', modelId: 'gemini-4-hydrogen', harness: 'antigravity', clientModelId: null, tier: 'strong', efforts: ['low', 'medium', 'high', 'xhigh'], pool: 'antigravity-gemini', src: ['antigravity-models'], ctx: null, status: 'unconfirmed', note: `${AG_NOTE} "Extra" is "xhigh" in the CLI (example: --model gemini-4-hydrogen-xhigh).` },
  { id: 'antigravity.flash', family: 'Flash', displayName: 'Gemini 3.8 Flash', modelId: 'gemini-3.8-flash', harness: 'antigravity', clientModelId: null, tier: 'economy', efforts: ['low', 'medium', 'high'], pool: 'antigravity-gemini', src: ['antigravity-models'], ctx: null, status: 'unconfirmed', note: AG_NOTE },
];

// API prices in micros of USD per 1M tokens, checked on CHECKED. Cache write = shortest-lived write
// (OpenAI 30m, Anthropic 5m). Reasoning/thinking tokens are billed as output tokens (vendor convention;
// the pricing pages checked do not list a separate reasoning rate).
const usd = (x) => Math.round(x * 1000000);
const OAI_SRC = { url: 'https://developers.openai.com/api/docs/pricing', checkedAt: CHECKED };
const CLAUDE_SRC = { url: 'https://platform.claude.com/docs/en/about-claude/pricing', checkedAt: CHECKED };
const r = (i, cr, cw, o) => ({ uncachedInput: usd(i), cacheRead: usd(cr), cacheWrite: usd(cw), output: usd(o), reasoning: null });
const PRICES = {
  'codex.astra': { source: OAI_SRC, rates: r(10, 1, 12.5, 50), longContext: { thresholdTokens: 272000, rates: r(20, 2, 25, 75) } },
  'codex.sol': { source: OAI_SRC, rates: r(2, 0.1, 2.5, 10), longContext: { thresholdTokens: 272000, rates: r(4, 0.2, 5, 15) } },
  'codex.terra': { source: OAI_SRC, rates: r(1, 0.05, 1.25, 5), longContext: { thresholdTokens: 272000, rates: r(2, 0.1, 2.5, 7.5) } },
  'codex.luna': { source: OAI_SRC, rates: r(0.1, 0.01, 0.125, 0.5), longContext: { thresholdTokens: 272000, rates: r(0.2, 0.02, 0.25, 0.75) } },
  'claude-code.opus': { source: CLAUDE_SRC, rates: r(4, 0.2, 5, 20), longContext: null },
  'claude-code.sonnet': { source: CLAUDE_SRC, rates: r(2, 0.1, 2.5, 10), longContext: null },
  'claude-code.haiku': { source: CLAUDE_SRC, rates: r(0.1, 0.01, 0.125, 0.5), longContext: { thresholdTokens: 100000, rates: r(0.5, 0.05, 0.625, 2.5) } },
};

// Independent index records (config/benchmarks.json) used as proxy evidence for apply factors that have
// an explicit proxy mapping. Values stay tier-derived; the record only confirms the tier ordering inside
// each harness (see references/benchmarks.md). Verify has no mapping and stays heuristic.
const INDEX_RECORD = {
  'claude-code.opus': ['aa-cai-2.1.claude-code.opus-5-5.max', 'max', 58],
  'claude-code.sonnet': ['aa-cai-2.1.claude-code.sonnet-5-5.max', 'max', 56],
  'codex.astra': ['aa-cai-2.1.codex.astra.max', 'max', 53],
  'codex.sol': ['aa-cai-2.1.codex.sol.max', 'max', 52],
  'codex.terra': ['aa-cai-2.1.codex.terra.max', 'max', 49],
  'antigravity.argon': ['aa-cai-2.1.antigravity.argon.high', 'high', 45],
};
const PROXY_APPLY_FACTORS = ['volume', 'domains', 'layers', 'architecture', 'logic'];

function coefficients(tier, phase, efforts, modelKey) {
  const base = {};
  const rec = phase === 'apply' ? INDEX_RECORD[modelKey] : undefined;
  for (const f of FACTOR_IDS) {
    const value = TIER_BASE[phase][tier] + (TIER_FACTOR_ADJ[tier][f] || 0);
    const tierText = `tier "${tier}" ${phase} baseline${TIER_FACTOR_ADJ[tier][f] ? ` with ${TIER_FACTOR_ADJ[tier][f]} for deep-reasoning factor` : ''}`;
    if (rec && PROXY_APPLY_FACTORS.includes(f)) {
      base[f] = {
        value,
        status: 'proxy',
        basis: `${tierText}; tier order cross-checked against AA Coding Agent Index v2.1 = ${rec[2]} at effort ${rec[1]} (aggregate coding index, proxy for ${f}, not a direct measurement)`,
        sources: [rec[0]],
      };
    } else {
      base[f] = {
        value,
        status: 'heuristic',
        basis: `${tierText}; vendor positioning, no comparable independent ${phase} measurement for this factor`,
      };
    }
  }
  const effortDelta = {};
  for (const e of efforts) {
    if (EFFORT_DELTA[e] === 0) continue;
    effortDelta[e] = { deltaBp: EFFORT_DELTA[e], status: 'heuristic', basis: `effort ${e} relative to medium (uniform heuristic)` };
  }
  return { base, effortDelta };
}

const perPhase = (fn, efforts) => ({
  apply: Object.fromEntries(efforts.map((e) => [e, fn('apply', e)])),
  verify: Object.fromEntries(efforts.map((e) => [e, fn('verify', e)])),
});

const models = MODELS.map((m) => ({
  id: m.id,
  family: m.family,
  displayName: m.displayName,
  modelId: m.modelId,
  harness: m.harness,
  clientModelId: m.clientModelId,
  enabled: true,
  availability: 'unknown',
  supportedEfforts: m.efforts,
  contextWindowTokens: m.ctx,
  capabilities: null,
  identity: { status: m.status, checkedAt: CHECKED, sources: m.src, note: m.note },
  coefficients: { apply: coefficients(m.tier, 'apply', m.efforts, m.id), verify: coefficients(m.tier, 'verify', m.efforts, m.id) },
  api: {
    pricingId: `${m.id}.standard`,
    usageMultiplierBp: perPhase((phase, e) => EFFORT_USAGE[e], m.efforts),
    basis: 'token usage scales with effort (uniform heuristic); per-task calibration is not available yet',
  },
  subscription: {
    poolId: m.pool,
    loadMultiplierBp: perPhase((phase, e) => Math.floor(TIER_LOAD[m.tier] * EFFORT_USAGE[e] / 10000), m.efforts),
    basis: `relative plan load: tier "${m.tier}" factor ${TIER_LOAD[m.tier]} × effort usage; not a quota percentage`,
  },
  time: {
    multiplierBp: perPhase((phase, e) => Math.floor(TIER_TIME[m.tier] * EFFORT_USAGE[e] / 10000), m.efforts),
    basis: `relative wall time: tier "${m.tier}" factor ${TIER_TIME[m.tier]} × effort usage`,
  },
}));

const unknownRates = { uncachedInput: null, cacheRead: null, cacheWrite: null, output: null, reasoning: null };
const pricing = MODELS.map((m) => {
  const p = PRICES[m.id];
  if (!p) {
    return {
      id: `${m.id}.standard`, status: 'unknown', currency: 'USD', tier: 'standard', rates: unknownRates,
      reasoningBilling: 'as-output', longContext: null, toolCharges: {},
      note: 'No public per-token API price for this model in this harness was found on a primary page; the cost stays unknown (never zero). Fill rates via overrides with a source.',
    };
  }
  return {
    id: `${m.id}.standard`, status: 'confirmed', currency: 'USD', tier: 'standard', source: p.source, rates: p.rates,
    reasoningBilling: 'as-output', longContext: p.longContext, toolCharges: {},
    note: `Standard tier list price, micros per 1M tokens. Cache write = ${m.harness === 'codex' ? '30-minute' : '5-minute'} write rate. Batch, fast mode, regional and priority surcharges are not modelled.${p.longContext ? ` Prompts above ${p.longContext.thresholdTokens} input tokens use the long-context rates.` : ''}`,
  };
});

// ---------------------------------------------------------------------------- workloads
const CATS = [['xs', 2000, 1, 40000], ['s', 4000, 3, 80000], ['m', 6000, 8, 150000], ['l', 8000, 20, 250000], ['xl', 10000, 50, 400000]];
const XS_APPLY = { uncachedInputTokens: 30000, cacheReadTokens: 120000, cacheWriteTokens: 20000, outputTokens: 6000, reasoningTokens: 8000 };
const SCEN = { low: 5000, typical: 10000, high: 25000 };
const PHASE_SCALE = { apply: 10000, verify: 6000 };
const scale = (v, ...bps) => bps.reduce((x, b) => Math.floor(x * b / 10000), v);

function apiWorkload(phase) {
  const out = {};
  for (const [id, , mult, peak] of CATS) {
    out[id] = {};
    for (const [s, sb] of Object.entries(SCEN)) {
      const u = {};
      for (const [k, v] of Object.entries(XS_APPLY)) u[k] = scale(v * mult, sb, PHASE_SCALE[phase]);
      u.peakContextTokens = s === 'high' ? Math.floor(peak * 3 / 2) : peak;
      u.toolCalls = {};
      out[id][s] = u;
    }
  }
  return out;
}
function scalarWorkload(phase, xs) {
  const out = {};
  for (const [id, , mult] of CATS) {
    out[id] = {};
    for (const [s, sb] of Object.entries(SCEN)) out[id][s] = scale(xs * mult, sb, PHASE_SCALE[phase]);
  }
  return out;
}

const defaults = {
  kind: 'openspec-assess.config',
  schemaVersion: 1,
  catalog: {
    verifiedAt: CHECKED,
    note: 'Ten pinned families as named by the owner, checked on the primary pages below. Versions are fixed; there is no automatic "latest". Public availability does not mean the account has the model or quota: account availability is configured separately (availability field). Antigravity client IDs are unpublished and stay unconfirmed.',
    sources: [
      { id: 'openai-models', url: 'https://developers.openai.com/api/docs/models', title: 'OpenAI models' },
      { id: 'codex-models', url: 'https://learn.chatgpt.com/docs/models', title: 'Codex models' },
      { id: 'claude-models', url: 'https://platform.claude.com/docs/en/about-claude/models/overview', title: 'Claude models overview' },
      { id: 'claude-code-models', url: 'https://code.claude.com/docs/en/model-config', title: 'Claude Code model configuration' },
      { id: 'antigravity-models', url: 'https://antigravity.google/docs/models', title: 'Antigravity models' },
    ],
  },
  complexityRules: {
    volumeThresholds: { tasks: [1, 4, 10, 25], files: [1, 4, 12, 40], diffLines: [50, 300, 1200, 5000] },
    groups: {
      volume: { volume: 1 },
      complexity: { domains: 2, layers: 1, architecture: 3, logic: 3, compatibility: 1 },
      risk: { consequences: 3, compatibility: 2, testability: 2 },
      uncertainty: { uncertainty: 1 },
    },
    unknownRankingLevel: 3,
    workloadCategories: CATS.map(([id, upToBp]) => ({ id, upToBp })),
    basis: 'Volume thresholds follow the rubric anchors; group weights emphasise architecture and logic for complexity and consequences for risk. Unknown levels rank as 3 (conservative) and keep 0..4 bounds.',
  },
  phases: {
    apply: {
      relevanceWeights: { volume: 2, domains: 2, layers: 2, architecture: 3, logic: 3, compatibility: 2, testability: 1, consequences: 2, uncertainty: 2 },
      qualityFloors: [{ fromDemandBp: 0, floorBp: 5000 }, { fromDemandBp: 3000, floorBp: 6000 }, { fromDemandBp: 5000, floorBp: 6800 }, { fromDemandBp: 7000, floorBp: 7600 }, { fromDemandBp: 8500, floorBp: 8000 }],
      criticalFactors: [{ factor: 'consequences', whenLevelAtLeast: 3, minCoefficientBp: 7500 }, { factor: 'architecture', whenLevelAtLeast: 4, minCoefficientBp: 7500 }],
      basis: 'Apply weights favour architecture and logic; floors rise with the upper bound of complexity/risk. Policy values, not benchmark facts.',
    },
    verify: {
      relevanceWeights: { volume: 1, domains: 2, layers: 1, architecture: 2, logic: 2, compatibility: 2, testability: 3, consequences: 3, uncertainty: 2 },
      qualityFloors: [{ fromDemandBp: 0, floorBp: 5000 }, { fromDemandBp: 3000, floorBp: 6000 }, { fromDemandBp: 5000, floorBp: 6600 }, { fromDemandBp: 7000, floorBp: 7400 }, { fromDemandBp: 8500, floorBp: 7800 }],
      criticalFactors: [{ factor: 'consequences', whenLevelAtLeast: 3, minCoefficientBp: 7500 }, { factor: 'testability', whenLevelAtLeast: 3, minCoefficientBp: 7000 }],
      basis: 'Verify weights favour testability and consequences. Policy values, not benchmark facts.',
    },
  },
  workloads: {
    basis: 'Scenario workloads per category (xs..xl) and phase; high includes possible rework. Uncalibrated heuristics until local completed changes are measured.',
    api: { apply: apiWorkload('apply'), verify: apiWorkload('verify') },
    subscription: { apply: scalarWorkload('apply', 10), verify: scalarWorkload('verify', 10) },
    timeMinutes: { apply: scalarWorkload('apply', 10), verify: scalarWorkload('verify', 10) },
  },
  harnesses: [
    { id: 'codex', name: 'Codex', docs: 'https://developers.openai.com/codex' },
    { id: 'claude-code', name: 'Claude Code', docs: 'https://code.claude.com/docs' },
    { id: 'antigravity', name: 'Antigravity IDE', docs: 'https://antigravity.google/docs' },
  ],
  models,
  pricing,
  quotaPools: [
    { id: 'codex-plan', harness: 'codex', label: 'Codex subscription plan', observation: null, conversion: null, note: 'Modelled as one plan-level pool; the Codex models page does not state how limits are split across models. Split it with overrides if your plan shows per-model limits.' },
    { id: 'claude-plan', harness: 'claude-code', label: 'Claude subscription plan', observation: null, conversion: null, note: 'Modelled as one plan-level pool for Claude Code; confirm against the usage view of your plan.' },
    { id: 'antigravity-gemini', harness: 'antigravity', label: 'Antigravity plan: Gemini models', observation: null, conversion: null, note: 'Antigravity tracks Gemini models and Claude/GPT models in separate limits (weekly and five-hour); all three catalog models are Gemini and share this pool.' },
  ],
  constraints: { minContextTokens: null, requiredCapabilities: [], api: { maxCostMicros: null } },
  selection: {
    api: { currency: 'USD', weights: { quality: 7, economy: 3, time: 0 }, anchors: { costMicros: 20000000, timeMinutes: 480 } },
    subscription: { weights: { quality: 7, economy: 3, time: 0 }, anchors: { load: 1000, timeMinutes: 480 } },
    basis: 'Baseline prioritises quality (7:3); anchors are fixed so adding a candidate never rescales others. Published policy, not a benchmark fact.',
  },
};

const text = canonicalStringify(defaults, { pretty: true });
if (process.argv.includes('--check')) {
  const current = readFileSync(out, 'utf8');
  if (current !== text) { console.error('config/defaults.json is out of date; run node scripts/build-defaults.mjs'); process.exit(1); }
  console.log('config/defaults.json is up to date');
} else {
  writeFileSync(out, text);
  console.log(`wrote ${out}`);
}
