# Миграция config v1 → v2

Пакет 0.1.0 хранил качество модели как `base[factor]` + общая `effortDelta[effort]` (и необязательный `byEffort`), ресурсы — как таблицы множителей. Пакет 0.2.0 (config/overrides schema 2, evaluator 2, renderer 2) требует **явную запись** для каждой фазы × supported effort × параметра и для каждого ресурса. Старые документы не интерпретируются молча: CLI и конфигуратор отклоняют `schemaVersion: 1` с подсказкой выполнить миграцию.

## Команда

```bash
# overrides активного change (assessment/overrides.json v1) поверх поставлявшихся v1 defaults
node bin/openspec-assess.mjs migrate-config --change <name> --out <changeRoot>/assessment/config.json

# или явные файлы
node bin/openspec-assess.mjs migrate-config --from-defaults my-v1-defaults.json --overrides my-v1-overrides.json --out migrated.json
```

По умолчанию старые defaults — `config/legacy/defaults-v1.json` (точная копия поставки 0.1.0). Результат — полный config v2 для review/export; входные файлы не перезаписываются (`--out` должен отличаться от входов, существующий файл заменяется только с `--force`), запись в `assessment/runs/` запрещена.

Чтобы использовать результат: сохраните его как `<changeRoot>/assessment/config.json` (подхватывается автоматически) или передавайте `--defaults <file>`; удалите или замените v1 `assessment/overrides.json`.

## Правила

1. Старый effective config собирается из выбранных v1 defaults и overrides **по правилам v1** (`src/core/legacy/v1.mjs` — неизменённая копия кода 0.1.0).
2. Для каждого supported effort каждого параметра обеих фаз:
   - есть `byEffort[effort][factor]` → берётся это значение (приоритет v1 сохранён), статус и источники записи сохраняются;
   - иначе `clamp(base + effortDelta, 0, 10000)`; отсутствующая delta = 0; неизвестный base → `unknown` для всех efforts.
3. Происхождение: `base + 0` сохраняет статус base; `base + ненулевая delta` — составное значение → `heuristic` (или `user-override`, если обе части пользовательские); `measured` при другом effort источника → `proxy`. Источники, которые больше не выводят число, переходят в `support`. Исходные v1-данные (base, delta, признак clamping) сохраняются в `migratedFrom`. Миграция не создаёт измерений.
4. Ресурсы: `usageMultiplierBp`, `loadMultiplierBp`, `multiplierBp` → записи `resources.*` по фазе и effort (`heuristic`, либо `user-override`, если значение задавалось v1-override; отсутствующее → `unknown`).
5. Копируются без изменений: enabled, `efforts`, доступность, контекст, capabilities, идентичность, цены, quota pools, ограничения, веса фаз, пороги, workloads и предпочтения.

## Что проверено

- `test/migration.test.mjs` распаковывает настоящий пакет 0.1.0 (`test/fixtures/v1/openspec-assess-change-0.1.0.tgz`) и сравнивает его отчёт с отчётом нового evaluator на мигрированном config: suitability, вклады, utility, cost/load/time, рекомендуемый effort, остальные efforts, исключения и порядок совпадают — для подлинного v1-run из архива и для синтетического v1-config с `byEffort`, ненулевыми и отрицательными delta, clamping и unknown base.
- Новый run получает новый assessment-id и version identity; побайтовое совпадение со старым report не обещается.

## История не мигрирует

Открытие конфигуратора, `replay` и `check-freshness` не меняют прежние runs, manifests и `latest.json`. Replay v1-run новым пакетом завершается кодом 4 и сообщением «Install openspec-assess-change 0.1.0»; совместимый 0.1.0 воспроизводит его байт в байт (проверено тестом). Новый `assess` после миграции добавляет отдельный run и запись в историю `latest.json`, старый run остаётся неизменным. Rollback — вернуть сохранённые v1 config/overrides и использовать release 0.1.0; ни новые, ни старые snapshots при этом не удаляются.

Обновление baseline (новые поставляемые оценки 0.2.0) — отдельный шаг: мигрированный config сохраняет **ваши прежние числа**, а не новые defaults.
